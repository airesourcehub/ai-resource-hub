#!/bin/bash
# AI Resource Hub - GPU Connector (keep this window open)
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then echo " Run install-linux.sh first."; read -r -p "Press Enter to close"; exit 1; fi
.venv/bin/python connector/agent.py
read -r -p "Press Enter to close"
