@echo off
setlocal
cd /d "%~dp0"
title AI Resource Hub - GPU Connector (keep open)
if not exist ".venv\Scripts\python.exe" (
  echo  Run Install-Windows.cmd first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" "connector\agent.py"
echo.
pause
