AI Resource Hub — GPU Connector
================================
Lets airesourcehub.vip make images and videos on YOUR computer's graphics card.
Only your account can use your PC. Nothing is shared with other members.

What you need
  * Windows 10/11 or Linux with an NVIDIA RTX card (12 GB+ VRAM; 24 GB for video tools)
    — or a Mac with Apple Silicon (Fast images only, slower)
  * 30–200 GB free disk space, depending on the model packs you pick
  * Your AI Resource Hub account

1) Get your PC token
   Sign in at https://www.airesourcehub.vip/gpu and click "Connect a PC".
   Copy the token it shows (it starts with airhpc_). It's shown once.

2) Install
   Windows: double-click  Install-Windows.cmd
            (If Windows SmartScreen appears: More info -> Run anyway)
   Mac:     right-click  Install-Mac.command -> Open -> Open
            (or in Terminal:  bash Install-Mac.command)
   Linux:   bash install-linux.sh
   Paste your token, pick "Install ComfyUI for me" (or point it at your own ComfyUI),
   and choose model packs. Downloads resume if they get interrupted.

3) Go online
   Windows: double-click  Start-Windows.cmd
   Mac:     right-click  Start-Mac.command -> Open
   Linux:   bash start-linux.sh
   When it says ONLINE, open https://www.airesourcehub.vip/image-studio.html.
   Keep the window open while you create. Close it to go offline.

Add more models later: run the Install file again.
Remove this PC: delete it on https://www.airesourcehub.vip/gpu, then delete this folder.

Files it creates in this folder: tools/ (uv, cloudflared, 7-Zip, ffmpeg), comfyui/ (if it
installed ComfyUI for you), .venv/, jobs/ (your renders), logs/, config.json (your PC token —
keep it private).
