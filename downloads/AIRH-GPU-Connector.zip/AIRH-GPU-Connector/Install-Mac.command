#!/bin/bash
# AI Resource Hub - GPU Connector setup (macOS)
cd "$(dirname "$0")" || exit 1
echo ""
echo " AI Resource Hub - GPU Connector setup"
echo " -------------------------------------"
if [ "$(uname -m)" = "arm64" ]; then T=aarch64-apple-darwin; else T=x86_64-apple-darwin; fi
mkdir -p tools
if [ ! -x tools/uv ]; then
  echo " Getting the Python helper (uv)..."
  curl -LsSf "https://github.com/astral-sh/uv/releases/latest/download/uv-$T.tar.gz" | tar -xz --strip-components 1 -C tools
fi
if [ ! -x tools/uv ]; then echo " Couldn't download uv. Check your internet and run this again."; read -r -p "Press Enter to close"; exit 1; fi
AIRH_UV="$PWD/tools/uv" tools/uv run --python 3.12 --with requests connector/setup.py
echo ""
read -r -p "Press Enter to close"
