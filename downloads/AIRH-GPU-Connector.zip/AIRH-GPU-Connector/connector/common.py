# AI Resource Hub — GPU Connector: shared helpers for setup.py and agent.py
import json
import os
import platform
import re
import subprocess
import sys
from pathlib import Path

VERSION = "1.0.0"
ROOT = Path(__file__).resolve().parent.parent          # the AIRH-GPU-Connector folder
HERE = ROOT / "connector"
SERVER_DIR = HERE / "server"
TOOLS = ROOT / "tools"
CONFIG = ROOT / "config.json"
LOGS = ROOT / "logs"

SUPABASE_URL = "https://flzhhgfkpdmszucoljpu.supabase.co"
SUPABASE_ANON_KEY = "sb_publishable_tU7xub6uYy-mUdFI0LI3XQ_tiyaixjw"   # public key (same one the website uses)
CONNECT_FN = SUPABASE_URL + "/functions/v1/gpu-connect"
SITE = "https://www.airesourcehub.vip"

IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")
COMFY_PORT = 8190      # the connector's own ComfyUI (kept off 8188 so it never clashes with yours)
SERVER_PORT = 8797     # the connector's local API (the tunnel points here)


def os_name():
    if IS_WIN:
        return "Windows"
    if IS_MAC:
        return "macOS (Apple Silicon)" if platform.machine() == "arm64" else "macOS (Intel)"
    return "Linux"


def load_config():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg):
    CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def detect_gpu():
    """Best-effort GPU name + memory in GB."""
    if IS_MAC:
        name, mem = "Apple GPU", None
        try:
            name = subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"], timeout=5).decode().strip() or name
            mem = round(int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], timeout=5)) / 1e9)
        except Exception:
            pass
        return {"name": name, "vram_gb": mem, "kind": "apple", "shared_memory": True}
    try:
        out = subprocess.check_output(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                                      timeout=10).decode("utf-8", "ignore").strip().splitlines()
        if out:
            name, mem = [x.strip() for x in out[0].split(",")[:2]]
            return {"name": name, "vram_gb": round(float(mem) / 1024), "kind": "nvidia"}
    except Exception:
        pass
    return {"name": "No NVIDIA GPU found", "vram_gb": None, "kind": "none"}


def load_packs():
    return json.loads((HERE / "packs.json").read_text(encoding="utf-8"))["packs"]


def installed_packs(models_dir):
    """Packs whose every file is present."""
    out = []
    if not models_dir:
        return out
    md = Path(models_dir)
    for p in load_packs():
        if all((md / sub / fn).is_file() for sub, fn, _u, _g in p["files"]):
            out.append(p["id"])
    return out


def workflow_files(path):
    """(folder-guess, filename) for every model file a ComfyUI API workflow loads."""
    try:
        wf = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return []
    out = []
    for node in wf.values():
        if not isinstance(node, dict):
            continue
        for v in (node.get("inputs") or {}).values():
            if isinstance(v, str) and re.search(r"\.(safetensors|gguf|onnx|pt|pth|ckpt)$", v, re.I):
                out.append(v)
    return out


def find_model_file(models_dir, filename):
    md = Path(models_dir)
    for sub in ("diffusion_models", "unet", "checkpoints", "text_encoders", "clip", "vae", "loras",
                "clip_vision", "detection", "latent_upscale_models", "upscale_models"):
        if (md / sub / filename).is_file():
            return True
    try:   # anything else, one level down
        return any(p.name == filename for p in md.glob("*/" + filename))
    except Exception:
        return False
