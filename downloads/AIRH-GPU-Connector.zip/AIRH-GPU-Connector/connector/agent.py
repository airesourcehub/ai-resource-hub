# AI Resource Hub — GPU Connector (run with Start-Windows.cmd / Start-Mac.command / start-linux.sh)
# Starts ComfyUI (if the connector installed it), the local render service, and a
# Cloudflare quick tunnel, then tells airesourcehub.vip where to find this PC.
# Keep the window open while you create. Close it (or press Ctrl+C) to go offline.
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from common import (CONNECT_FN, LOGS, ROOT, SERVER_DIR, SERVER_PORT, SITE, SUPABASE_ANON_KEY, SUPABASE_URL,
                    VERSION, detect_gpu, installed_packs, load_config, os_name)

import requests  # noqa: E402

CHILDREN = []
STOP = threading.Event()


def say(msg):
    print(time.strftime("[%H:%M:%S] ") + msg, flush=True)


def start_child(cmd, log_name, cwd=None, env=None):
    LOGS.mkdir(exist_ok=True)
    log = open(LOGS / log_name, "a", encoding="utf-8", errors="replace")
    flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    p = subprocess.Popen([str(c) for c in cmd], cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT,
                         creationflags=flags)
    CHILDREN.append(p)
    return p


def wait_for(url, seconds, label):
    t0 = time.time()
    while time.time() - t0 < seconds:
        try:
            if requests.get(url, timeout=3).status_code == 200:
                return True
        except Exception:
            pass
        time.sleep(2)
    say(f"! {label} didn't answer at {url} within {seconds}s")
    return False


def start_tunnel(cf):
    """cloudflared quick tunnel -> returns (process, https url)."""
    LOGS.mkdir(exist_ok=True)
    flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    p = subprocess.Popen([cf, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{SERVER_PORT}"],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                         creationflags=flags)
    CHILDREN.append(p)
    found = {"url": None}
    log = open(LOGS / "tunnel.log", "a", encoding="utf-8", errors="replace")

    def pump():
        for line in p.stdout:
            log.write(line)
            log.flush()
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
            if m and not found["url"]:
                found["url"] = m.group(0)
    threading.Thread(target=pump, daemon=True).start()
    t0 = time.time()
    while not found["url"] and time.time() - t0 < 60 and p.poll() is None:
        time.sleep(0.5)
    return p, found["url"]


def main():
    cfg = load_config()
    if not cfg.get("token") or not cfg.get("comfy"):
        say("Setup isn't finished. Run the Install file first.")
        return 1
    print("=" * 64)
    print("  AI Resource Hub — GPU Connector v" + VERSION)
    print("  Keep this window open while you create. Close it to go offline.")
    print("=" * 64, flush=True)

    comfy = cfg["comfy"]
    models_dir = str(Path(comfy["dir"]) / "models")
    gpu = detect_gpu()
    packs = installed_packs(models_dir)
    say(f"{os_name()} · {gpu['name']}" + (f" · {gpu['vram_gb']} GB" if gpu.get("vram_gb") else ""))
    say("Model packs: " + (", ".join(packs) if packs else "none yet — run the Install file again to add some"))

    # 1) ComfyUI
    if comfy.get("managed") and comfy.get("launch"):
        try:
            up = requests.get(comfy["url"] + "/system_stats", timeout=2).status_code == 200
        except Exception:
            up = False
        if not up:
            say("Starting ComfyUI (first start can take a couple of minutes)...")
            start_child(comfy["launch"], "comfyui.log", cwd=str(Path(comfy["dir"]).parent))
    else:
        say(f"Using your own ComfyUI at {comfy['url']} — make sure it's running.")
    if not wait_for(comfy["url"] + "/system_stats", 300, "ComfyUI"):
        say(f"! Check {LOGS / 'comfyui.log'}. The connector will keep trying in the background.")

    # 2) local render service (the same one the site's main GPU runs) in member mode
    env_add = {
        "SUPABASE_URL": SUPABASE_URL, "SUPABASE_ANON_KEY": SUPABASE_ANON_KEY,
        "SUPABASE_SERVICE_ROLE_KEY": "member-mode-no-admin-key",
        "COMFY_URL": comfy["url"], "PORT": str(SERVER_PORT), "WORK_DIR": str(ROOT / "jobs"),
        "COMFY_LORA_DIR": str(Path(models_dir) / "loras"), "IMAGE_WF_DIR": str(SERVER_DIR / "image_workflows"),
        "PUBLIC_BASE_URL": "http://127.0.0.1:%d" % SERVER_PORT, "MCP_TOKEN": "",
    }
    os.environ.update(env_add)
    if cfg.get("ffmpeg_dir"):
        os.environ["PATH"] = cfg["ffmpeg_dir"] + os.pathsep + os.environ.get("PATH", "")
    (Path(models_dir) / "loras").mkdir(parents=True, exist_ok=True)
    os.chdir(SERVER_DIR)
    sys.path.insert(0, str(SERVER_DIR))
    import member_mode
    member_mode.STATE.update(token=cfg["token"], models_dir=models_dir, comfy_url=comfy["url"],
                             pc_name=cfg.get("pc_name"))
    member_mode.install_requests_hook()
    import server as S          # noqa: E402  (reads the env above)
    import mcp_tools            # noqa: E402
    member_mode.apply(S, mcp_tools)

    import uvicorn
    srv = uvicorn.Server(uvicorn.Config(S.app, host="127.0.0.1", port=SERVER_PORT, log_level="warning"))
    threading.Thread(target=srv.run, daemon=True).start()
    if not wait_for(f"http://127.0.0.1:{SERVER_PORT}/health", 60, "The connector service"):
        return 1

    # 3) tunnel + register, then heartbeat
    cf = cfg.get("cloudflared")
    tunnel, url = None, None
    last_beat = 0
    info = {}
    while not STOP.is_set():
        if tunnel is None or tunnel.poll() is not None:
            say("Opening a secure link to the website...")
            tunnel, url = start_tunnel(cf)
            if not url:
                say("! Couldn't open the link. Retrying in 15 s (see logs/tunnel.log)")
                time.sleep(15)
                tunnel = None
                continue
            info = {"os": os_name(), "gpu": gpu, "packs": installed_packs(models_dir),
                    "models": member_mode.available_model_ids(S), "version": VERSION}
            member_mode.STATE["info"] = info
            try:
                r = requests.post(CONNECT_FN, json={"action": "register", "token": cfg["token"], "url": url,
                                                    "info": info}, timeout=20)
                j = r.json()
            except Exception as e:
                say(f"! Couldn't reach the website ({e}). Retrying...")
                time.sleep(10)
                continue
            if r.status_code != 200:
                say("! " + (j.get("error") or "The website refused this PC."))
                if j.get("revoked") or r.status_code == 401:
                    say("  Make a new PC token on the website and run the Install file again.")
                    return 1
                time.sleep(15)
                continue
            member_mode.STATE.update(owner=j["user_id"], secret=j.get("proxy_secret"), pc_name=j.get("name"))
            member_mode.set_public_url(mcp_tools, url)
            last_beat = time.time()
            say(f"ONLINE as \"{j.get('name')}\".  Open {SITE}/image-studio.html and start creating.")
            say("Only your account can use this PC.")
        if time.time() - last_beat > 60:
            try:
                r = requests.post(CONNECT_FN, json={"action": "heartbeat", "token": cfg["token"]}, timeout=20)
                if r.status_code == 401:
                    say("! This PC was removed from your account on the website. Going offline.")
                    return 1
                last_beat = time.time()
            except Exception:
                pass
        time.sleep(2)
    return 0


def shutdown():
    cfg = load_config()
    try:
        requests.post(CONNECT_FN, json={"action": "offline", "token": cfg.get("token", "")}, timeout=8)
    except Exception:
        pass
    for p in CHILDREN:
        try:
            p.terminate()
        except Exception:
            pass


if __name__ == "__main__":
    code = 0
    try:
        code = main() or 0
    except KeyboardInterrupt:
        print("\nGoing offline...")
    finally:
        STOP.set()
        shutdown()
    sys.exit(code)
