# AI Resource Hub — GPU Connector setup (Windows, macOS, Linux)
# Run through Install-Windows.cmd / Install-Mac.command / install-linux.sh.
# Safe to run again any time: add model packs, change your PC token, or repair.
import os
import shutil
import subprocess
import sys
import tarfile
import time
import zipfile
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (CONFIG, COMFY_PORT, CONNECT_FN, IS_LINUX, IS_MAC, IS_WIN, ROOT, SITE, TOOLS, VERSION,
                    detect_gpu, installed_packs, load_config, load_packs, os_name, save_config)

UV = os.environ.get("AIRH_UV") or shutil.which("uv") or "uv"
UA = {"User-Agent": "airh-gpu-connector/" + VERSION}


def say(msg=""):
    print(msg, flush=True)


def ask(q, default=""):
    try:
        a = input(q + (f" [{default}]" if default else "") + ": ").strip()
    except EOFError:
        a = ""
    return a or default


def yes(q, default=True):
    a = ask(q + (" (Y/n)" if default else " (y/N)")).lower()
    return default if not a else a.startswith("y")


def run(cmd, **kw):
    say("  > " + " ".join(str(c) for c in cmd))
    subprocess.run([str(c) for c in cmd], check=True, **kw)


def download(url, dest, label=None, expect_gb=None):
    """Resumable download with a progress line. Skips files that are already complete."""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_file() and dest.stat().st_size > 0:
        say(f"  ✓ {label or dest.name} (already here)")
        return dest
    part = dest.with_name(dest.name + ".part")
    have = part.stat().st_size if part.exists() else 0
    headers = dict(UA)
    if have:
        headers["Range"] = f"bytes={have}-"
    for attempt in range(1, 6):
        try:
            with requests.get(url, stream=True, headers=headers, timeout=60, allow_redirects=True) as r:
                if r.status_code == 416:      # already complete
                    break
                if have and r.status_code != 206:
                    have = 0
                    part.unlink(missing_ok=True)
                r.raise_for_status()
                total = int(r.headers.get("content-length") or 0) + have
                done, t0, last = have, time.time(), 0
                with open(part, "ab" if have else "wb") as f:
                    for chunk in r.iter_content(4 * 1024 * 1024):
                        f.write(chunk)
                        done += len(chunk)
                        now = time.time()
                        if now - last > 0.5:
                            last = now
                            speed = (done - have) / max(now - t0, 0.001) / 1e6
                            pct = f"{done * 100 / total:5.1f}%" if total else ""
                            sys.stdout.write(f"\r  ↓ {label or dest.name}: {done / 1e9:6.2f} GB {pct}  {speed:5.1f} MB/s   ")
                            sys.stdout.flush()
            sys.stdout.write("\n")
            break
        except Exception as e:
            have = part.stat().st_size if part.exists() else 0
            headers = dict(UA)
            if have:
                headers["Range"] = f"bytes={have}-"
            say(f"\n  ! download hiccup ({e}); retrying {attempt}/5 ...")
            time.sleep(3 * attempt)
    else:
        raise SystemExit(f"Couldn't download {url}. Check your internet and run setup again — it picks up where it left off.")
    part.replace(dest)
    say(f"  ✓ {label or dest.name}")
    return dest


# ---------------------------------------------------------------- steps
def step_token(cfg):
    say("\nSTEP 1 — Link this PC to your account")
    say(f"  On {SITE}/gpu click 'Connect a PC', then copy the PC token it shows (starts with airhpc_).")
    while True:
        cur = cfg.get("token", "")
        t = ask("  Paste your PC token" + (" (Enter keeps the current one)" if cur else ""), "").strip() or cur
        if not t:
            continue
        try:
            r = requests.post(CONNECT_FN, json={"action": "heartbeat", "token": t}, headers=UA, timeout=20)
            j = r.json()
        except Exception as e:
            say(f"  ! Couldn't reach the website ({e}). Check your internet and try again.")
            continue
        if r.status_code == 200 and j.get("ok"):
            cfg["token"] = t
            cfg["pc_name"] = j.get("name") or "My PC"
            say(f"  ✓ Linked as \"{cfg['pc_name']}\"")
            return
        say("  ! " + (j.get("error") or "That token didn't work.") + " Make a new one on the website and paste it here.")


def comfy_portable_install(cfg):
    base = ROOT / "comfyui"
    sevenz = download("https://www.7-zip.org/a/7zr.exe", TOOLS / "7zr.exe", "7-Zip extractor")
    arc = download("https://github.com/Comfy-Org/ComfyUI/releases/latest/download/ComfyUI_windows_portable_nvidia.7z",
                   base / "ComfyUI_windows_portable_nvidia.7z", "ComfyUI for Windows (about 2 GB)")
    say("  Unpacking ComfyUI (a few minutes)...")
    run([sevenz, "x", "-y", f"-o{base}", arc], stdout=subprocess.DEVNULL)
    arc.unlink(missing_ok=True)
    port = base / "ComfyUI_windows_portable"
    cfg["comfy"] = {
        "managed": True,
        "dir": str(port / "ComfyUI"),
        "url": f"http://127.0.0.1:{COMFY_PORT}",
        "launch": [str(port / "python_embeded" / "python.exe"), "-s", str(port / "ComfyUI" / "main.py"),
                   "--windows-standalone-build", "--listen", "127.0.0.1", "--port", str(COMFY_PORT),
                   "--disable-auto-launch"],
    }


def comfy_source_install(cfg):
    base = ROOT / "comfyui"
    base.mkdir(parents=True, exist_ok=True)
    zp = download("https://github.com/Comfy-Org/ComfyUI/archive/refs/heads/master.zip", base / "ComfyUI.zip", "ComfyUI source")
    say("  Unpacking ComfyUI...")
    with zipfile.ZipFile(zp) as z:
        z.extractall(base)
    zp.unlink(missing_ok=True)
    src = next(base.glob("ComfyUI-*"), None)
    dst = base / "ComfyUI"
    if src and not dst.exists():
        src.rename(dst)
    venv = base / "venv"
    run([UV, "venv", venv, "--python", "3.12"])
    py = venv / ("Scripts/python.exe" if IS_WIN else "bin/python")
    say("  Installing PyTorch + ComfyUI requirements (several GB, be patient)...")
    if IS_LINUX:
        run([UV, "pip", "install", "--python", py, "torch", "torchvision", "torchaudio",
             "--index-url", "https://download.pytorch.org/whl/cu128"])
    else:
        run([UV, "pip", "install", "--python", py, "torch", "torchvision", "torchaudio"])
    run([UV, "pip", "install", "--python", py, "-r", dst / "requirements.txt"])
    cfg["comfy"] = {
        "managed": True, "dir": str(dst), "url": f"http://127.0.0.1:{COMFY_PORT}",
        "launch": [str(py), str(dst / "main.py"), "--listen", "127.0.0.1", "--port", str(COMFY_PORT)],
    }


def step_comfy(cfg):
    say("\nSTEP 2 — ComfyUI (the engine that runs the AI models)")
    have = cfg.get("comfy")
    if have and Path(have.get("dir", "")).is_dir():
        say(f"  Current: {have['dir']} ({'started by the connector' if have.get('managed') else 'you start it yourself'})")
        if not yes("  Change it?", False):
            return
    say("  1) Install ComfyUI for me (recommended)")
    say("  2) I already have ComfyUI — use my copy")
    c = ask("  Choose 1 or 2", "1")
    if c == "2":
        while True:
            d = Path(ask("  Folder that contains ComfyUI's main.py").strip('"').strip("'")).expanduser()
            if (d / "main.py").is_file() and (d / "models").is_dir():
                break
            say("  ! That folder doesn't have main.py and a models folder. Try again.")
        url = ask("  Address your ComfyUI runs on", "http://127.0.0.1:8188").rstrip("/")
        cfg["comfy"] = {"managed": False, "dir": str(d), "url": url, "launch": None}
        say("  ✓ Using your ComfyUI. Start it yourself before you start the connector.")
        return
    if IS_WIN:
        comfy_portable_install(cfg)
    else:
        comfy_source_install(cfg)
    say("  ✓ ComfyUI installed")


def step_packs(cfg, gpu):
    say("\nSTEP 3 — Pick what you want to make (model packs)")
    models_dir = Path(cfg["comfy"]["dir"]) / "models"
    have = set(installed_packs(models_dir))
    packs = load_packs()
    vram = gpu.get("vram_gb") or 0
    for i, p in enumerate(packs, 1):
        tag = "installed" if p["id"] in have else f"{p['gb']:.0f} GB"
        warn = ""
        if IS_MAC and not p["mac"]:
            warn = "  (not on Mac)"
        elif not IS_MAC and vram and vram < p["min_vram"]:
            warn = f"  (needs {p['min_vram']} GB+ VRAM — yours has {vram})"
        say(f"  {i}) {p['name']} — {tag}{warn}")
        say(f"     {p['about']}")
    free = shutil.disk_usage(models_dir if models_dir.exists() else ROOT).free / 1e9
    say(f"  Free disk space here: {free:.0f} GB")
    default = "1" if "images_fast" not in have else ""
    pick = ask("  Type the numbers to download, like 1,2 (Enter to skip)", default)
    chosen = []
    for tok in pick.replace(" ", "").split(","):
        if tok.isdigit() and 1 <= int(tok) <= len(packs):
            p = packs[int(tok) - 1]
            if IS_MAC and not p["mac"]:
                say(f"  - Skipping {p['name']}: it needs an NVIDIA card.")
                continue
            chosen.append(p)
    seen = set()
    need = sum(g for p in chosen for sub, fn, u, g in p["files"]
               if (sub, fn) not in seen and not seen.add((sub, fn)) and not (models_dir / sub / fn).is_file())
    if need > free - 5:
        say(f"  ! These need about {need:.0f} GB but only {free:.0f} GB is free. Free up space or pick fewer.")
        if not yes("  Download anyway?", False):
            return
    for p in chosen:
        say(f"\n  {p['name']}")
        for sub, fn, url, _gb in p["files"]:
            download(url, models_dir / sub / fn, f"{sub}/{fn}")
    if any(p["id"] in ("motion", "transitions", "lipsync") for p in chosen) or (have & {"motion", "transitions", "lipsync"}):
        step_ffmpeg(cfg)


def step_ffmpeg(cfg):
    if shutil.which("ffmpeg") or cfg.get("ffmpeg_dir"):
        return
    if IS_WIN:
        say("\n  Video tools need ffmpeg — downloading it...")
        z = download("https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip", TOOLS / "ffmpeg.zip", "ffmpeg")
        with zipfile.ZipFile(z) as zf:
            zf.extractall(TOOLS / "ffmpeg")
        z.unlink(missing_ok=True)
        binp = next((TOOLS / "ffmpeg").glob("*/bin"), None)
        if binp:
            cfg["ffmpeg_dir"] = str(binp)
    else:
        say("\n  Video tools need ffmpeg. Install it with:  sudo apt install ffmpeg  (Linux)  or  brew install ffmpeg  (Mac)")


def step_cloudflared(cfg):
    say("\nSTEP 4 — Secure link to the website (Cloudflare tunnel)")
    if IS_WIN:
        exe = download("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe",
                       TOOLS / "cloudflared.exe", "cloudflared")
    else:
        exe = TOOLS / "cloudflared"
        if not exe.is_file():
            if IS_MAC:
                arch = "arm64" if os.uname().machine == "arm64" else "amd64"
                tgz = download(f"https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-{arch}.tgz",
                               TOOLS / "cloudflared.tgz", "cloudflared")
                with tarfile.open(tgz) as t:
                    t.extractall(TOOLS)
                tgz.unlink(missing_ok=True)
            else:
                download("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
                         exe, "cloudflared")
            exe.chmod(0o755)
    cfg["cloudflared"] = str(exe)
    say("  ✓ Ready (no Cloudflare account needed)")


def step_venv(cfg):
    say("\nSTEP 5 — Connector app")
    venv = ROOT / ".venv"
    py = venv / ("Scripts/python.exe" if IS_WIN else "bin/python")
    if not py.exists():
        run([UV, "venv", venv, "--python", "3.12"])
    run([UV, "pip", "install", "--python", py, "-r", ROOT / "connector" / "requirements.txt"])
    say("  ✓ Installed")


def main():
    say("=" * 64)
    say("  AI Resource Hub — GPU Connector setup  v" + VERSION)
    say("  Lets airesourcehub.vip use YOUR graphics card. Only you can use it.")
    say("=" * 64)
    gpu = detect_gpu()
    say(f"  This computer: {os_name()} · {gpu['name']}" + (f" · {gpu['vram_gb']} GB" if gpu.get("vram_gb") else ""))
    if gpu["kind"] == "none":
        say("  ! No NVIDIA graphics card was found. The connector works best with an NVIDIA RTX card (12 GB+).")
        if not yes("  Continue anyway?", False):
            return
    if IS_MAC:
        say("  Note: on a Mac only the Fast images pack runs, and slower than on an NVIDIA PC.")
    cfg = load_config()
    TOOLS.mkdir(exist_ok=True)
    step_token(cfg); save_config(cfg)
    step_comfy(cfg); save_config(cfg)
    step_packs(cfg, gpu); save_config(cfg)
    step_cloudflared(cfg); save_config(cfg)
    step_venv(cfg)
    cfg["setup_version"] = VERSION
    save_config(cfg)
    start = "Start-Windows.cmd" if IS_WIN else ("Start-Mac.command" if IS_MAC else "start-linux.sh")
    say("\n" + "=" * 64)
    say(f"  All set! Double-click {start} to go online.")
    say(f"  Then open {SITE}/image-studio.html — it will use this PC.")
    say("  Run this setup again any time to add more model packs.")
    say("=" * 64)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        say("\nSetup stopped. Run it again to continue — downloads pick up where they left off.")
    except subprocess.CalledProcessError as e:
        say(f"\n! A step failed ({e}). Run setup again; if it keeps failing, send a screenshot to the site admin.")
