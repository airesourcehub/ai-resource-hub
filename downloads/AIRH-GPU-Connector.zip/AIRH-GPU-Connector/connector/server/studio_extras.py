# AI Resource Hub — extra GPU workflows:
#   * 4K upscale (SeedVR2 7B int8, one-step diffusion upscaler)
#   * Character / object swap (WAN 2.1 SCAIL-2 + SAM 3 tracking)
#   * Style presets (restyle a reference image with Qwen Image Edit 2509)
#   * 480p / 720p sizing for WAN Animate motion jobs
# Kept apart from server.py so the graphs are easy to change.

import copy
import json
import random
from pathlib import Path

WF_DIR = Path("image_workflows")
UPSCALE_WF = WF_DIR / "upscale_seedvr2_api.json"
SWAP_WF = WF_DIR / "swap_scail2_api.json"
RESTYLE_WF = WF_DIR / "image_qwen_image_edit_2509.json"

_cache = {}


def _load(path):
    if path not in _cache:
        _cache[path] = json.loads(Path(path).read_text(encoding="utf-8"))
    return copy.deepcopy(_cache[path])


def _seed():
    return random.randint(1, 2**50)


# ------------------------------------------------------------------ upscale
UPSCALE_LONG_SIDE = 4096


def build_upscale(image_name, long_side=UPSCALE_LONG_SIDE, prefix="airh/upscale"):
    wf = _load(UPSCALE_WF)
    wf["1"]["inputs"]["image"] = image_name
    wf["66:57"]["inputs"]["resize_type.longer_size"] = int(long_side)
    wf["66:54"]["inputs"]["seed"] = _seed()
    wf["9"]["inputs"]["filename_prefix"] = prefix
    return wf


# --------------------------------------------------------------------- swap
SWAP_FPS = 16
SEG_FRAMES = 81           # frames per SCAIL-2 segment
SEG_OVERLAP = 5           # frames the 2nd segment re-uses from the 1st
MAX_FRAMES = {5: SEG_FRAMES, 10: 2 * SEG_FRAMES - SEG_OVERLAP}   # 81 / 157

SIZES = {   # (landscape w, h); portrait swaps them. SCAIL wants multiples of 32.
    "480p": (832, 480),
    "720p": (1280, 704),
}
MOTION_SIZES = {  # WAN Animate (multiples of 16)
    "480p": (832, 480),
    "720p": (1280, 720),
}

DEFAULT_SWAP_PROMPT = ("The character from the reference image naturally performing the same "
                       "movements as the original video, consistent identity and outfit, "
                       "natural lighting, sharp focus, high detail, smooth realistic motion")
DEFAULT_MOTION_PROMPT = ("A cinematic video of the character performing the motion, natural "
                         "lighting, sharp focus, high detail, smooth realistic movement")


def swap_frames(n_available, secs):
    """Frames to use: at most 81 (5 s) or 157 (10 s), always 4k+1."""
    n = max(5, min(int(n_available), MAX_FRAMES[10 if secs == 10 else 5]))
    return ((n - 1) // 4) * 4 + 1


def size_for(res, portrait, table=SIZES):
    w, h = table.get(res, table["720p"])
    return (h, w) if portrait else (w, h)


def build_swap(video_name, ref_name, *, prompt, target="person", ref_target=None,
               width=832, height=480, extend=False, prefix="airh/swap"):
    """SCAIL-2 character replacement. extend=True adds the 2nd segment (up to 157 frames)."""
    wf = _load(SWAP_WF)
    if extend:
        for k in ("201", "202"):            # first-segment-only save
            wf.pop(k, None)
        wf["271"]["inputs"]["filename_prefix"] = prefix
    else:
        for k in [k for k in wf if k.startswith("262:")] + ["269", "270", "271"]:
            wf.pop(k, None)
        wf["202"]["inputs"]["filename_prefix"] = prefix
    target = (target or "person").strip()[:120] or "person"
    ref_target = (ref_target or target).strip()[:120] or target
    wf["155"]["inputs"]["file"] = video_name
    wf["30"]["inputs"]["image"] = ref_name
    seg = {"213": {"prompt": "3", "video_txt": "191", "ref_txt": "212", "w": "178", "h": "179", "seed": "19"},
           "262": {"prompt": "258", "video_txt": "242", "ref_txt": "261", "w": "236", "h": "237", "seed": "227"}}
    for p, ids in seg.items():
        if f"{p}:{ids['prompt']}" not in wf:
            continue
        wf[f"{p}:{ids['prompt']}"]["inputs"]["text"] = prompt or DEFAULT_SWAP_PROMPT
        wf[f"{p}:{ids['video_txt']}"]["inputs"]["text"] = target
        wf[f"{p}:{ids['ref_txt']}"]["inputs"]["text"] = ref_target
        wf[f"{p}:{ids['w']}"]["inputs"]["value"] = int(width)
        wf[f"{p}:{ids['h']}"]["inputs"]["value"] = int(height)
        wf[f"{p}:{ids['seed']}"]["inputs"]["noise_seed"] = _seed()
    return wf


# ------------------------------------------------------------ motion sizing
def set_motion_size(wf, width, height):
    for n in wf.values():
        t = ((n.get("_meta") or {}).get("title") or "").upper()
        if n.get("class_type") == "PrimitiveInt":
            if t.startswith("WIDTH"):
                n["inputs"]["value"] = int(width)
            elif t.startswith("HEIGHT"):
                n["inputs"]["value"] = int(height)
    return wf


# ------------------------------------------------------------------ styles
# Our own preset list. The site shows a preview tile for each id
# (img/styles/<id>.jpg). "custom" uses the user's own text.
_KEEP = (" Keep the same character, face shape, pose, outfit, framing and background layout; "
         "only change the visual style.")
STYLE_PRESETS = {
    "anime":      ("Anime",        "Redraw this image as a hand-drawn Japanese anime illustration with clean line art, cel shading and vivid colours."),
    "animated3d": ("3D Animated",  "Turn this image into a 3D animated feature-film render with soft global illumination, smooth stylised skin and big expressive eyes."),
    "clay":       ("Claymation",   "Turn this image into a claymation stop-motion character: the person, hair and clothes are sculpted from plasticine with a soft rounded handmade look, simplified features, visible fingerprints and tool marks."),
    "comic":      ("Comic Ink",    "Redraw this image as a bold comic-book panel with heavy black ink outlines, halftone dots and flat saturated colours."),
    "watercolor": ("Watercolor",   "Repaint this image as a loose watercolor painting on textured paper with soft bleeding edges and gentle washes of colour."),
    "oil":        ("Oil Painting", "Repaint this image as a classical oil painting with rich impasto brush strokes and warm, dramatic chiaroscuro lighting."),
    "cyberpunk":  ("Neon City",    "Restyle this image as a cyberpunk night scene with neon magenta and cyan rim lighting, glowing signs and light rain haze."),
    "noir":       ("Film Noir",    "Restyle this image as a black-and-white 1940s film noir still with hard shadows, venetian-blind light and film grain."),
    "retro":      ("70s Film",     "Restyle this image as a faded 1970s 35mm film photograph with warm colour cast, soft grain and slight light leaks."),
    "sketch":     ("Pencil Sketch","Redraw this image as a detailed graphite pencil sketch on white paper with cross-hatching and smudged shading."),
    "pixel":      ("Pixel Art",    "Convert this image into retro 16-bit video game pixel art: chunky clearly visible square pixels, very low resolution, limited colour palette, no smooth gradients or fine detail."),
    "statue":     ("Marble Statue","Turn the character into a polished white marble statue with carved details, keeping the same pose, in soft museum lighting."),
    "plush":      ("Plush Toy",    "Turn the character into a soft stitched plush toy made of felt and fleece fabric, keeping the same pose."),
    "photoreal":  ("Photoreal",    "Turn this image into a realistic high-end photograph of a real person with natural skin texture and true-to-life lighting."),
}


def style_prompt(style, custom=""):
    style = (style or "").strip().lower()
    if style == "custom":
        c = (custom or "").strip()[:600]
        return (f"Restyle this image: {c}." + _KEEP) if c else None
    p = STYLE_PRESETS.get(style)
    return (p[1] + _KEEP) if p else None


def public_styles():
    return [{"id": k, "name": v[0]} for k, v in STYLE_PRESETS.items()]


def build_restyle(image_name, prompt, style_image_name=None, prefix="airh/restyle"):
    """Qwen Image Edit 2509 (4-step Lightning). Optional 2nd image = style reference."""
    wf = _load(RESTYLE_WF)
    wf["78"]["inputs"]["image"] = image_name
    wf["433:111"]["inputs"]["prompt"] = prompt
    wf["433:3"]["inputs"]["seed"] = _seed()
    wf["469"]["inputs"]["filename_prefix"] = prefix
    if style_image_name:
        wf["s1"] = {"class_type": "LoadImage", "inputs": {"image": style_image_name},
                    "_meta": {"title": "STYLE_IMAGE"}}
        wf["s2"] = {"class_type": "FluxKontextImageScale", "inputs": {"image": ["s1", 0]},
                    "_meta": {"title": "Style scale"}}
        for k in ("433:110", "433:111"):
            wf[k]["inputs"]["image2"] = ["s2", 0]
        wf["433:111"]["inputs"]["prompt"] = (
            "Redraw image 1 in the exact art style, colour palette and rendering of image 2. "
            + (prompt if prompt else "") + _KEEP)
    return wf


# ---------------------------------------------------------------- captions
# Qwen3-VL 8B (loaded through the ideogram4 text-encoder path, which supports
# multimodal generation) describes the reference character, so the swap
# prompt carries its identity. Without this SCAIL-2 keeps the original face.
CAPTION_PROMPT = ("Describe the main character in this image for a video generation prompt. In one paragraph of "
                  "60-90 words, state: what they are (person, animal, creature, object), apparent gender and age, "
                  "skin or fur colour, face and hair (colour, length, style), facial hair, eyewear, every clothing "
                  "item with colours, shoes and accessories, and the art style if it is not a photo. Describe only "
                  "the character, not the background or pose. No preamble.")


def build_caption(image_name):
    return {
        "c1": {"class_type": "CLIPLoader", "inputs": {"clip_name": "qwen3vl_8b_fp8_scaled.safetensors",
                                                     "type": "ideogram4", "device": "default"}},
        "c2": {"class_type": "LoadImage", "inputs": {"image": image_name}},
        "c3": {"class_type": "TextGenerate", "inputs": {"clip": ["c1", 0], "prompt": CAPTION_PROMPT, "max_length": 220,
                                                       "sampling_mode": "off", "image": ["c2", 0], "thinking": False,
                                                       "use_default_template": True, "mtp": "off"}},
        "c4": {"class_type": "PreviewAny", "inputs": {"source": ["c3", 0]}},
    }


def swap_prompt(caption, user_prompt):
    action = (user_prompt or "").strip() or "The character naturally performs the same movements as the person in the original video."
    parts = [caption.strip()] if caption and caption.strip() else []
    parts.append(action)
    parts.append("Same identity, face, hair and outfit as the reference in every frame, natural lighting, sharp focus, smooth realistic motion.")
    return " ".join(parts)


# ------------------------------------------------------------ video upscale
# SeedVR2 7B (video mode, temporal chunks) takes a 720p render to 1080p.
VUPSCALE_WF = WF_DIR / "vupscale_seedvr2_api.json"
VIDEO_LONG_SIDE = 1920


def build_video_upscale(video_name, long_side=VIDEO_LONG_SIDE, prefix="airh/vupscale"):
    wf = _load(VUPSCALE_WF)
    wf["73"]["inputs"]["file"] = video_name
    wf["66:57"]["inputs"]["resize_type.longer_size"] = int(long_side)
    wf["66:54"]["inputs"]["seed"] = _seed()
    wf["76"]["inputs"]["filename_prefix"] = prefix
    return wf
