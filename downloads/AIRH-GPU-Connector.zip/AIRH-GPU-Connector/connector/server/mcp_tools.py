# AI Resource Hub — MCP connector for the render service.
#
# Lets Claude (claude.ai custom connector, Claude Code, the desktop app) drive
# the hub: check the GPU, generate images and AI influencers, run motion
# transfer and lip sync, watch jobs and list results. Everything runs as the
# owner account set in .env (MCP_USER_ID) and goes through the same single-GPU
# queue as the website.
#
# Endpoint:  POST https://render.airesourcehub.vip/mcp   (MCP "streamable HTTP", JSON replies)
# Auth:      header  Authorization: Bearer <MCP_TOKEN>   (or X-API-Key: <MCP_TOKEN>)
#
# .env:  MCP_TOKEN=<long random secret>    MCP_USER_ID=<Supabase user id that owns the jobs>
#
# Wired in server.py with:  import mcp_tools; mcp_tools.register(app, sys.modules[__name__])

import os
import json
import time
import uuid
import hmac
import shutil
from pathlib import Path

import requests
from fastapi import Request
from fastapi.responses import JSONResponse, Response

PUBLIC_BASE = os.environ.get("PUBLIC_BASE_URL", "https://render.airesourcehub.vip").rstrip("/")
SITE = "https://www.airesourcehub.vip"
PROTOCOLS = ["2025-06-18", "2025-03-26", "2024-11-05"]
MAX_DOWNLOAD = 250 * 1024 * 1024

INSTRUCTIONS = (
    "Tools for AI Resource Hub (airesourcehub.vip). Every render runs on the hub's own RTX 3090 GPU, "
    "one job at a time, so jobs queue. Start a job, then call wait_for_job (repeat it if it is still running) "
    "and share the result URLs. Images: generate_image (Z-Image Turbo 'zimage' is fastest; FLUX.2 'flux2' is "
    "best quality; edit models need image_url). Characters: create_influencer saves to your AI Influencer page. "
    "Video: motion_transfer (image + driving video) and lip_sync (image + audio). Media inputs must be public "
    "https URLs, or result URLs from this server."
)

S = None  # the server module (set in register)
import threading as _th
import hashlib as _hl
_CUR = _th.local()          # .user = {"id": ...} for the request being handled
_KEY_CACHE = {}             # sha256 -> (user_id, key_id, expires_at)
MAX_OPEN_JOBS_PER_USER = 3


# ------------------------------------------------------------------ helpers
def _abs(u):
    if not u:
        return u
    return u if u.startswith("http") else PUBLIC_BASE + (u if u.startswith("/") else "/" + u)


def _owner():
    """The account the current MCP request acts as."""
    u = getattr(_CUR, "user", None)
    if u and u.get("id"):
        return u
    raise ValueError("Not signed in to AI Resource Hub")


def _limit_open_jobs(user):
    if user.get("owner"):
        return
    open_jobs = [j for j in S.JOBS.values() if j.get("user_id") == user["id"] and j.get("status") in ("queued", "processing", "running")]
    if len(open_jobs) >= MAX_OPEN_JOBS_PER_USER:
        raise ValueError("You already have %d jobs waiting on the GPU. Let them finish first." % len(open_jobs))


def _fetch_to(url, dest):
    """Copy a URL into dest. Our own /files/ URLs are read straight from disk."""
    url = (url or "").strip()
    if not url.startswith("https://") and not url.startswith("http://"):
        raise ValueError("Media must be an http(s) URL: " + url[:80])
    local_prefix = PUBLIC_BASE + "/files/"
    if url.startswith(local_prefix):
        rel = url[len(local_prefix):].split("?")[0]
        job_id, _, name = rel.partition("/")
        src = S.WORK_DIR / job_id / name
        if src.exists() and ".." not in rel:
            shutil.copyfile(src, dest)
            return
    with requests.get(url, stream=True, timeout=60, headers={"User-Agent": "airh-mcp/1.0"}) as r:
        r.raise_for_status()
        size = 0
        with open(dest, "wb") as out:
            for chunk in r.iter_content(1024 * 1024):
                size += len(chunk)
                if size > MAX_DOWNLOAD:
                    raise ValueError("File is larger than 250 MB")
                out.write(chunk)


def _new_dir():
    job_id = str(uuid.uuid4())
    d = S.WORK_DIR / job_id
    d.mkdir(parents=True, exist_ok=True)
    return job_id, d


def _clamp(v, lo, hi, dv):
    try:
        return max(lo, min(hi, int(v)))
    except Exception:
        return dv


def _service_get(path, params):
    r = requests.get(f"{S.SUPABASE_URL}/rest/v1/{path}", params=params,
                     headers={"Authorization": f"Bearer {S.SERVICE_ROLE}", "apikey": S.SERVICE_ROLE}, timeout=20)
    r.raise_for_status()
    return r.json()


def _service_post(path, body):
    r = requests.post(f"{S.SUPABASE_URL}/rest/v1/{path}",
                      headers={"Authorization": f"Bearer {S.SERVICE_ROLE}", "apikey": S.SERVICE_ROLE,
                               "Content-Type": "application/json", "Prefer": "return=representation"},
                      data=json.dumps(body), timeout=20)
    r.raise_for_status()
    return r.json()


def _job_view(job_id):
    job = S.JOBS.get(job_id)
    if not job:
        return None
    me = getattr(_CUR, "user", None) or {}
    if job.get("user_id") != me.get("id") and not me.get("owner"):
        return None
    with S.LOCK:
        pos = S.QUEUE_IDS.index(job_id) if job_id in S.QUEUE_IDS else None
    out = {"job_id": job_id, "kind": job.get("kind"), "status": job.get("status"),
           "progress": job.get("progress"), "stage": job.get("stage"),
           "eta_seconds": job.get("eta_seconds"), "error": job.get("error")}
    if pos is not None:
        out["queue_ahead"] = pos
    urls = job.get("urls") or ([job["result_url"]] if job.get("result_url") else [])
    if urls:
        out["result_urls"] = [_abs(u) for u in urls]
    return out


# ------------------------------------------------------------------ tools
INFLUENCER_SHOTS = {
    "full": (832, 1216, "Full-body fashion photo, head to toe, of",
             "standing straight and facing the camera, whole body in frame including shoes"),
    "portrait": (896, 1152, "Close-up portrait photo, head and shoulders, of", "looking straight into the camera"),
    "sheet": (1344, 768, "Character turnaround reference sheet of",
              "shown four times side by side as the exact same character: front view, three-quarter view, "
              "side profile and back view, all full body, identical outfit and features"),
}
NEGATIVE = "blurry, deformed, extra limbs, extra fingers, bad anatomy, watermark, text, logo, cropped head, child, minor, nsfw"


def t_gpu_status(a):
    with S.LOCK:
        waiting = len(S.QUEUE_IDS)
    cur = S.JOBS.get(S.CURRENT_JOB_ID) if S.CURRENT_JOB_ID else None
    return {"engine_running": S._comfy_up(), "busy": S.BUSY, "jobs_waiting": waiting,
            "current_job": ({"job_id": S.CURRENT_JOB_ID, "kind": cur.get("kind"), "stage": cur.get("stage"),
                             "progress": cur.get("progress")} if cur else None),
            "gpus": S.read_gpu()}


def t_list_image_models(a):
    return {"models": S.public_models(),
            "tips": "zimage = fastest on the 3090; flux2 = best quality (slower); qwen_edit2509 / qwen_edit2511 / "
                    "firered / flux2_edit edit a photo (pass image_url)."}


def t_list_loras(a):
    d = os.environ.get("COMFY_LORA_DIR", "")
    names = []
    if d and Path(d).is_dir():
        names = sorted(p.name for p in Path(d).glob("*.safetensors"))
    return {"loras": names}


def t_generate_image(a):
    user = _owner()
    _limit_open_jobs(user)
    S._seat_gate(user)
    model = (a.get("model") or "zimage").strip()
    m = S.model_by_id(model)
    if not m:
        raise ValueError("Unknown model. Call list_image_models.")
    prompt = (a.get("prompt") or "").strip()
    if not prompt:
        raise ValueError("prompt is required")
    job_id, d = _new_dir()
    edit_size = False
    try:
        if m["type"] == "edit":
            if not a.get("image_url"):
                raise ValueError(m["name"] + " edits a photo: pass image_url.")
            _fetch_to(a["image_url"], d / "input.png")
            edit_size = bool(a.get("width") and a.get("height"))
    except Exception:
        shutil.rmtree(d, ignore_errors=True)
        raise
    S.JOBS[job_id] = S._new_job(
        id=job_id, kind="image", model=model, image_mode=("edit" if m["type"] == "edit" else "create"),
        prompt=prompt, negative=(a.get("negative") or ""),
        width=_clamp(a.get("width", 1024), 256, 2048, 1024), height=_clamp(a.get("height", 1024), 256, 2048, 1024),
        batch=_clamp(a.get("batch", 1), 1, 4, 1), lora=(a.get("lora") or "").strip(),
        lora_strength=float(a.get("lora_strength") or 1.0), user_id=user["id"], edit_size=edit_size)
    S.enqueue(job_id)
    return {"job_id": job_id, "status": "queued", "model": model,
            "next": "Call wait_for_job with this job_id. Results also appear in Image Studio: " + SITE + "/image-studio"}


def t_create_influencer(a):
    user = _owner()
    desc = (a.get("description") or "").strip()
    if not desc:
        raise ValueError("description is required, e.g. 'young adult Black man, braids, streetwear hoodie, gold grill'")
    shot = a.get("shot") if a.get("shot") in INFLUENCER_SHOTS else "full"
    w, h, lead, tail = INFLUENCER_SHOTS[shot]
    engine = a.get("engine") if a.get("engine") in ("zimage", "flux2") else "zimage"
    photo = a.get("photo_url")
    prompt = (lead + " " + desc + ", fully clothed. " + tail +
              ". plain light grey studio backdrop, soft even studio lighting, photorealistic, natural skin texture, "
              "sharp focus, high detail, editorial fashion photography.")
    if photo:
        prompt = ("Transform the person in this photo into the following character, keeping their face, facial "
                  "structure and identity clearly recognizable. " + prompt)
    res = t_generate_image({"model": "qwen_edit2509" if photo else engine, "prompt": prompt, "negative": NEGATIVE,
                            "width": w, "height": h, "batch": a.get("batch", 1), "image_url": photo})
    name = (a.get("name") or "").strip() or "Influencer"
    try:
        _service_post("influencers", {
            "user_id": user["id"], "name": name[:40], "tier": "normal",
            "traits": {"description": desc[:500]} if not isinstance(a.get("traits"), dict) else a["traits"],
            "view": shot, "model": "qwen_edit2509" if photo else engine, "prompt": prompt,
            "job_id": res["job_id"], "from_photo": bool(photo)})
    except Exception as e:
        res["warning"] = "Render queued but saving to the AI Influencer list failed: " + str(e)[:200]
    res["name"] = name
    res["next"] = "Call wait_for_job. It will show under My influencers at " + SITE + "/influencer?tab=mine"
    return res


def t_list_influencers(a):
    user = _owner()
    rows = _service_get("influencers", {"select": "id,name,tier,view,model,job_id,created_at",
                                        "user_id": "eq." + user["id"], "order": "created_at.desc",
                                        "limit": str(_clamp(a.get("limit", 20), 1, 100, 20))})
    ids = [r["job_id"] for r in rows if r.get("job_id")]
    jobs = {}
    if ids:
        for j in _service_get("image_jobs", {"select": "id,status,urls", "id": "in.(" + ",".join(ids) + ")"}):
            jobs[j["id"]] = j
    for r in rows:
        j = jobs.get(r.get("job_id")) or {}
        r["status"] = j.get("status")
        r["image_urls"] = [_abs(u) for u in (j.get("urls") or [])]
    return {"influencers": rows}


def t_motion_transfer(a):
    user = _owner()
    _limit_open_jobs(user)
    S._seat_gate(user)
    job_id, d = _new_dir()
    try:
        _fetch_to(a.get("image_url"), d / "reference.png")
        _fetch_to(a.get("video_url"), d / "drive.mp4")
    except Exception:
        shutil.rmtree(d, ignore_errors=True)
        raise
    orientation = "portrait" if a.get("orientation") == "portrait" else "landscape"
    quality = a.get("quality") == "quality"
    S.JOBS[job_id] = S._new_job(kind="motion_transfer", mode="motion_transfer", orientation=orientation,
                                length_secs=10 if str(a.get("length_seconds")) == "10" else 5,
                                fps=16, steps=8 if quality else 4,
                                prompt=(a.get("prompt") or "the character dancing, smooth natural motion"),
                                user_id=user["id"])
    S.JOBS[job_id]["id"] = job_id
    S.enqueue(job_id)
    return {"job_id": job_id, "status": "queued",
            "next": "Video jobs take several minutes. Call wait_for_job (repeat while running)."}


def t_lip_sync(a):
    user = _owner()
    _limit_open_jobs(user)
    S._seat_gate(user)
    job_id, d = _new_dir()
    audio_url = a.get("audio_url") or ""
    ext = (Path(audio_url.split("?")[0]).suffix or ".mp3").lower()
    if ext not in (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"):
        ext = ".mp3"
    try:
        _fetch_to(a.get("image_url"), d / "face.png")
        _fetch_to(audio_url, d / ("audio" + ext))
    except Exception:
        shutil.rmtree(d, ignore_errors=True)
        raise
    mime = {".wav": "audio/wav", ".m4a": "audio/mp4", ".aac": "audio/aac", ".ogg": "audio/ogg",
            ".flac": "audio/flac"}.get(ext, "audio/mpeg")
    S.JOBS[job_id] = S._new_job(id=job_id, kind="lipsync", mode="lipsync", prompt=(a.get("prompt") or ""),
                                audio_file="audio" + ext, audio_mime=mime, user_id=user["id"])
    S.enqueue(job_id)
    return {"job_id": job_id, "status": "queued", "next": "Call wait_for_job (repeat while running)."}


def t_job_status(a):
    v = _job_view(a.get("job_id", ""))
    if not v:
        raise ValueError("No such job in this server session (it may have finished before a restart).")
    return v


def t_wait_for_job(a):
    job_id = a.get("job_id", "")
    limit = _clamp(a.get("timeout_seconds", 90), 5, 110, 90)
    end = time.time() + limit
    while True:
        v = _job_view(job_id)
        if not v:
            raise ValueError("No such job in this server session.")
        if v["status"] in ("done", "error", "cancelled") or time.time() >= end:
            if v["status"] not in ("done", "error", "cancelled"):
                v["note"] = "Still running. Call wait_for_job again."
            return v
        time.sleep(3)


def t_cancel_job(a):
    job = S.JOBS.get(a.get("job_id", ""))
    me = _owner()
    if not job or (job.get("user_id") != me["id"] and not me.get("owner")):
        raise ValueError("No such job")
    job["cancel"] = True
    if S.CURRENT_JOB_ID == a.get("job_id"):
        S.comfy_reset()
    return {"ok": True}


def t_recent_results(a):
    user = _owner()
    n = str(_clamp(a.get("limit", 10), 1, 50, 10))
    imgs = _service_get("image_jobs", {"select": "id,model,prompt,status,urls,created_at", "user_id": "eq." + user["id"],
                                       "order": "created_at.desc", "limit": n})
    vids = _service_get("render_jobs", {"select": "id,mode,render_type,prompt,status,result_url,created_at",
                                        "user_id": "eq." + user["id"], "order": "created_at.desc", "limit": n})
    for r in imgs:
        r["urls"] = [_abs(u) for u in (r.get("urls") or [])]
        r["prompt"] = (r.get("prompt") or "")[:160]
    for r in vids:
        r["result_url"] = _abs(r.get("result_url"))
        r["prompt"] = (r.get("prompt") or "")[:160]
    return {"images": imgs, "videos": vids}


def _p(desc, **props):
    return {"type": "object", "properties": props, "description": desc}


S_STR = lambda d: {"type": "string", "description": d}
S_INT = lambda d: {"type": "integer", "description": d}

TOOLS = [
    ("gpu_status", "Is the RTX 3090 render machine up, busy, and how many jobs are waiting.", _p(""), t_gpu_status, True),
    ("list_image_models", "Image models available on the GPU (create vs edit).", _p(""), t_list_image_models, True),
    ("list_loras", "LoRA files installed on the render machine.", _p(""), t_list_loras, True),
    ("generate_image", "Queue an image on the GPU. Returns job_id; then call wait_for_job.",
     {**_p("", prompt=S_STR("What to make"), model=S_STR("Model id from list_image_models (default zimage)"),
           negative=S_STR("What to avoid"), width=S_INT("Width px (create models; edit models keep the photo size unless set)"),
           height=S_INT("Height px"), batch=S_INT("1-4 images"), image_url=S_STR("Photo to edit (edit models only)"),
           lora=S_STR("Optional LoRA filename"), lora_strength={"type": "number"}), "required": ["prompt"]},
     t_generate_image, False),
    ("create_influencer", "Create an AI influencer character (saved to the hub's AI Influencer page) from a description.",
     {**_p("", description=S_STR("Look of the character: age, ethnicity, gender, build, hair, outfit, features, accessories"),
           name=S_STR("Character name"), shot={"type": "string", "enum": ["full", "portrait", "sheet"]},
           engine={"type": "string", "enum": ["zimage", "flux2"]}, batch=S_INT("1-4"),
           photo_url=S_STR("Optional real face to base the character on")), "required": ["description"]},
     t_create_influencer, False),
    ("list_influencers", "Your saved AI influencers with image URLs.", _p("", limit=S_INT("Max rows")), t_list_influencers, True),
    ("motion_transfer", "Make a character copy the motion of a driving video (WAN 2.2 Animate).",
     {**_p("", image_url=S_STR("Character image URL"), video_url=S_STR("Driving video URL (mp4)"),
           prompt=S_STR("Scene description"), orientation={"type": "string", "enum": ["landscape", "portrait"]},
           length_seconds={"type": "integer", "enum": [5, 10]}, quality={"type": "string", "enum": ["fast", "quality"]}),
      "required": ["image_url", "video_url"]}, t_motion_transfer, False),
    ("lip_sync", "Make a face photo talk or sing an audio clip (LTX 2).",
     {**_p("", image_url=S_STR("Face image URL"), audio_url=S_STR("Audio URL (mp3/wav)"), prompt=S_STR("Optional scene notes")),
      "required": ["image_url", "audio_url"]}, t_lip_sync, False),
    ("job_status", "Current status of a job.", {**_p("", job_id=S_STR("Job id")), "required": ["job_id"]}, t_job_status, True),
    ("wait_for_job", "Wait (up to ~110 s) for a job to finish, then return status and result URLs.",
     {**_p("", job_id=S_STR("Job id"), timeout_seconds=S_INT("5-110")), "required": ["job_id"]}, t_wait_for_job, True),
    ("cancel_job", "Cancel a queued or running job.", {**_p("", job_id=S_STR("Job id")), "required": ["job_id"]}, t_cancel_job, False),
    ("recent_results", "Your latest rendered images and videos.", _p("", limit=S_INT("Max per type")), t_recent_results, True),
]
BY_NAME = {t[0]: t for t in TOOLS}


def _tool_list():
    out = []
    for name, desc, schema, _fn, ro in TOOLS:
        sch = dict(schema)
        sch.pop("description", None)
        out.append({"name": name, "description": desc, "inputSchema": sch,
                    "annotations": {"readOnlyHint": ro, "openWorldHint": False}})
    return out


# ------------------------------------------------------------------ JSON-RPC
def _lookup_key(key):
    """Personal keys made on airesourcehub.vip/mcp (stored as SHA-256 in mcp_keys)."""
    if not key or len(key) < 24:
        return None
    h = _hl.sha256(key.encode()).hexdigest()
    hit = _KEY_CACHE.get(h)
    now = time.time()
    if hit and hit[2] > now:
        return hit[0]
    try:
        rows = _service_get("mcp_keys", {"select": "id,user_id,revoked_at,last_used_at", "key_hash": "eq." + h, "limit": "1"})
    except Exception:
        return None
    if not rows or rows[0].get("revoked_at"):
        _KEY_CACHE[h] = (None, None, now + 30)
        return None
    uid = rows[0]["user_id"]
    _KEY_CACHE[h] = ({"id": uid}, rows[0]["id"], now + 60)
    try:  # remember when the key was last used (best effort)
        requests.patch(f"{S.SUPABASE_URL}/rest/v1/mcp_keys", params={"id": "eq." + rows[0]["id"]},
                       headers={"Authorization": f"Bearer {S.SERVICE_ROLE}", "apikey": S.SERVICE_ROLE,
                                "Content-Type": "application/json"},
                       data=json.dumps({"last_used_at": "now()"}), timeout=10)
    except Exception:
        pass
    return {"id": uid}


def _auth_user(request, path_key=None):
    got = path_key or request.headers.get("x-api-key", "")
    auth = request.headers.get("authorization", "")
    if not path_key and auth.lower().startswith("bearer "):
        got = auth.split(" ", 1)[1].strip()
    got = (got or "").strip()
    if not got:
        return None
    owner_token = os.environ.get("MCP_TOKEN", "").strip()
    if len(owner_token) >= 24 and hmac.compare_digest(got.encode(), owner_token.encode()):
        uid = os.environ.get("MCP_USER_ID", "").strip()
        return {"id": uid, "owner": True} if uid else None
    return _lookup_key(got)


def _run_as(user, msg):
    _CUR.user = user
    try:
        return _handle(msg)
    finally:
        _CUR.user = None


def _handle(msg):
    mid = msg.get("id")
    method = msg.get("method", "")
    params = msg.get("params") or {}
    if mid is None:  # notification
        return None
    if method == "initialize":
        req = params.get("protocolVersion")
        return {"jsonrpc": "2.0", "id": mid, "result": {
            "protocolVersion": req if req in PROTOCOLS else PROTOCOLS[0],
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "ai-resource-hub", "title": "AI Resource Hub", "version": "1.0.0"},
            "instructions": INSTRUCTIONS}}
    if method == "ping":
        return {"jsonrpc": "2.0", "id": mid, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": mid, "result": {"tools": _tool_list()}}
    if method == "tools/call":
        t = BY_NAME.get(params.get("name"))
        if not t:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": "Unknown tool"}}
        try:
            data = t[3](params.get("arguments") or {})
            return {"jsonrpc": "2.0", "id": mid, "result": {
                "content": [{"type": "text", "text": json.dumps(data, indent=1, default=str)}],
                "structuredContent": data, "isError": False}}
        except Exception as e:
            detail = getattr(e, "detail", None) or str(e)
            return {"jsonrpc": "2.0", "id": mid, "result": {
                "content": [{"type": "text", "text": "Error: " + str(detail)[:500]}], "isError": True}}
    if method in ("resources/list", "prompts/list"):
        key = "resources" if method.startswith("resources") else "prompts"
        return {"jsonrpc": "2.0", "id": mid, "result": {key: []}}
    return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "Method not found"}}


def register(app, server_module):
    global S
    S = server_module

    from starlette.concurrency import run_in_threadpool

    async def _serve(request, path_key=None):
        if request.method == "OPTIONS":
            return Response(status_code=204)
        if request.method != "POST":
            return Response(status_code=405, headers={"Allow": "POST"})
        user = await run_in_threadpool(_auth_user, request, path_key)
        if not user:
            return JSONResponse({"error": "unauthorized",
                                 "hint": "Create a key at https://www.airesourcehub.vip/mcp and send it as 'Authorization: Bearer <key>'"},
                                status_code=401)
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}},
                                status_code=400)
        if isinstance(payload, list):
            out = [r for r in [await run_in_threadpool(_run_as, user, m) for m in payload] if r is not None]
            return JSONResponse(out) if out else Response(status_code=202)
        res = await run_in_threadpool(_run_as, user, payload)
        if res is None:
            return Response(status_code=202)
        return JSONResponse(res)

    @app.api_route("/mcp", methods=["POST", "GET", "DELETE", "OPTIONS"])
    async def mcp(request: Request):
        return await _serve(request)

    @app.api_route("/mcp/k/{key}", methods=["POST", "GET", "DELETE", "OPTIONS"])
    async def mcp_with_key(request: Request, key: str):
        # For apps that can't send headers (e.g. ChatGPT): the key rides in the URL.
        return await _serve(request, path_key=key)
