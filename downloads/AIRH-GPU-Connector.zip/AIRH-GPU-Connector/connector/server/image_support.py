# AI Resource Hub — Image Studio support: model registry + generic patcher.
# Kept separate from server.py so per-model tweaks are easy.

import random

# Each model card. workflow = file in image_workflows/. type = create | edit.
# lora = whether a custom LoRA can be stacked. thumb = optional preview image
# (img/models/<id>.jpg on the site; falls back to a gradient card).
IMAGE_MODELS = [
    {"id": "flux2",         "name": "FLUX.2",             "workflow": "image_flux2_text_to_image.json",                 "type": "create", "lora": True,  "note": "Best all-round quality. Built-in Turbo toggle."},
    {"id": "qwen2512",      "name": "Qwen-Image 2512",    "workflow": "image_qwen_Image_2512.json",                     "type": "create", "lora": True,  "note": "Strong prompt adherence and text."},
    {"id": "krea2",         "name": "Krea 2 Turbo",       "workflow": "image_krea2_turbo_t2i.json",                     "type": "create", "lora": True,  "note": "Fast, stylish."},
    {"id": "zimage",        "name": "Z-Image Turbo",      "workflow": "image_z_image_turbo.json",                       "type": "create", "lora": False, "note": "Very fast."},
    {"id": "anima",         "name": "Anima",              "workflow": "image_anima_preview.json",                       "type": "create", "lora": False, "note": "Stylized."},
    {"id": "hidream",       "name": "HiDream O1",         "workflow": "image_hidream_o1.json",                          "type": "create", "lora": False, "note": "High detail; reference-image aware."},
    {"id": "sd35",          "name": "Stable Diffusion 3.5","workflow": "sd3.5_simple_example.json",                     "type": "create", "lora": False, "note": "Classic, flexible."},
    {"id": "flux2_edit",    "name": "FLUX.2 Edit",        "workflow": "image_flux2.json",                               "type": "edit",   "lora": True,  "note": "Edit a photo with a prompt."},
    {"id": "qwen_edit",     "name": "Qwen Image Edit",    "workflow": "image_qwen_image_edit.json",                     "type": "edit",   "lora": True,  "note": "Instruction-based image edits."},
    {"id": "qwen_edit2509", "name": "Qwen Edit 2509",     "workflow": "image_qwen_image_edit_2509.json",                "type": "edit",   "lora": True,  "note": "Newer Qwen edit."},
    {"id": "qwen_edit2511", "name": "Qwen Edit 2511",     "workflow": "template_qwen_image_edit_2511_systms_action.json","type": "edit",  "lora": True,  "note": "Multi-reference edit."},
    {"id": "firered",       "name": "FireRed Edit",       "workflow": "image_firered_image_edit1_1.json",               "type": "edit",   "lora": True,  "note": "Detailed photo edits."},
]

_BY_ID = {m["id"]: m for m in IMAGE_MODELS}

TEXT_ENCODE_CLASSES = {"CLIPTextEncode", "TextEncodeQwenImageEdit", "TextEncodeQwenImageEditPlus"}
SAMPLER_MODEL_CONSUMERS = {"BasicGuider", "KSampler", "KSamplerAdvanced", "SamplerCustom"}
SIZE_HINTS = ("latent", "scheduler", "empty")


def model_by_id(mid):
    return _BY_ID.get(mid)


def public_models():
    return [{k: m[k] for k in ("id", "name", "type", "lora", "note")} for m in IMAGE_MODELS]


def _title(node):
    return (node.get("_meta") or {}).get("title", "") or ""


def _is_link(v):
    return isinstance(v, list) and len(v) == 2 and isinstance(v[0], str)


def _set_prompt_text(node, value):
    ins = node.get("inputs", {})
    for key in ("text", "prompt"):
        if key in ins and not _is_link(ins[key]):
            ins[key] = value
            return True
    return False


def _resolve_text_node(wf, link, seen=None):
    """Walk back from a conditioning link to the nearest text-encode node."""
    if seen is None:
        seen = set()
    if not _is_link(link):
        return None
    nid = link[0]
    if nid in seen:
        return None
    seen.add(nid)
    n = wf.get(nid)
    if not n:
        return None
    if n.get("class_type") in TEXT_ENCODE_CLASSES:
        return n
    for v in n.get("inputs", {}).values():
        if _is_link(v):
            got = _resolve_text_node(wf, v, seen)
            if got is not None:
                return got
    return None


def _set_size_input(wf, node, key, value):
    """Set width/height; if it's a link to a primitive, set the primitive."""
    ins = node.get("inputs", {})
    v = ins.get(key)
    if _is_link(v):
        src = wf.get(v[0])
        if src and "value" in src.get("inputs", {}) and not _is_link(src["inputs"]["value"]):
            src["inputs"]["value"] = value
    elif v is not None:
        ins[key] = value


def patch_image_workflow(wf, *, prompt, negative="", width=1024, height=1024, batch=1,
                         seed=None, lora_name="", lora_strength=1.0,
                         input_image=None, model_type="create", edit_size=False):
    """Patch a raw ComfyUI (API-format) image workflow in place.

    edit_size=True (edit models): render at width x height instead of the
    photo's own size. The photo still feeds the prompt/reference conditioning;
    only the canvas the sampler draws on changes (all edit workflows run at
    denoise 1, so the encoded photo latent only ever supplied the shape).
    """
    if seed is None:
        seed = random.randint(0, 2**63 - 1)

    # --- prompts: prefer graph (sampler positive/negative), then titles -----
    pos = neg = None
    for nid, n in wf.items():
        ins = n.get("inputs", {})
        ct = n.get("class_type", "")
        if ct in ("KSampler", "KSamplerAdvanced", "SamplerCustom") and _is_link(ins.get("positive")):
            pos = pos or _resolve_text_node(wf, ins["positive"])
            if _is_link(ins.get("negative")):
                neg = neg or _resolve_text_node(wf, ins["negative"])
        if ct == "BasicGuider" and _is_link(ins.get("conditioning")):
            pos = pos or _resolve_text_node(wf, ins["conditioning"])
    text_nodes = [n for n in wf.values() if n.get("class_type") in TEXT_ENCODE_CLASSES]
    if pos is None:
        for n in text_nodes:
            if "positive" in _title(n).lower():
                pos = n; break
        pos = pos or (text_nodes[0] if text_nodes else None)
    if neg is None:
        for n in text_nodes:
            if "negative" in _title(n).lower():
                neg = n; break
        if neg is None and len(text_nodes) >= 2:
            neg = next((n for n in text_nodes if n is not pos), None)
    if neg is pos:  # single-encoder workflows (negative is a zero-out) — don't clobber
        neg = None
    if pos is not None:
        _set_prompt_text(pos, prompt)
    if neg is not None:
        _set_prompt_text(neg, negative or "")
    # LLM-refiner workflows (Krea/HiDream) take the prompt via a "User Prompt" primitive
    for n in wf.values():
        if "user prompt" in _title(n).lower() and "value" in n.get("inputs", {}) and not _is_link(n["inputs"]["value"]):
            n["inputs"]["value"] = prompt

    # --- dimensions + batch (create mode only) ------------------------------
    for nid, n in wf.items():
        ins = n.get("inputs", {})
        ct = (n.get("class_type") or "").lower()
        if model_type == "create" and "width" in ins and "height" in ins and any(h in ct for h in SIZE_HINTS):
            _set_size_input(wf, n, "width", width)
            _set_size_input(wf, n, "height", height)
        if "batch_size" in ins and not _is_link(ins["batch_size"]):
            ins["batch_size"] = batch

    # --- custom output size for edit models ---------------------------------
    if model_type == "edit" and edit_size:
        _apply_edit_size(wf, width, height, batch)

    # --- seeds --------------------------------------------------------------
    for nid, n in wf.items():
        ins = n.get("inputs", {})
        for k in ("seed", "noise_seed"):
            if k in ins and not _is_link(ins[k]):
                ins[k] = random.randint(0, 2**63 - 1)

    # --- input image for edit models ----------------------------------------
    if model_type == "edit" and input_image:
        for nid, n in wf.items():
            if n.get("class_type") == "LoadImage" and "image" in n.get("inputs", {}):
                n["inputs"]["image"] = input_image

    # --- optional custom LoRA (stacked at the end of the model chain) -------
    if lora_name:
        consumer = None
        for nid, n in wf.items():
            if n.get("class_type") in SAMPLER_MODEL_CONSUMERS and _is_link(n.get("inputs", {}).get("model")):
                consumer = n
                break
        if consumer is not None:
            src = consumer["inputs"]["model"]
            wf["user_lora"] = {
                "class_type": "LoraLoaderModelOnly",
                "_meta": {"title": "User LoRA"},
                "inputs": {"model": src, "lora_name": lora_name,
                           "strength_model": float(lora_strength)},
            }
            consumer["inputs"]["model"] = ["user_lora", 0]

    return wf


LATENT_FROM_PHOTO = {"VAEEncode"}
SAMPLERS_WITH_LATENT = {"KSampler", "KSamplerAdvanced", "SamplerCustom", "SamplerCustomAdvanced"}


def _apply_edit_size(wf, width, height, batch):
    """Point edit samplers at an empty canvas of the chosen size."""
    width = int(width) // 16 * 16
    height = int(height) // 16 * 16
    # Nodes sized from the photo via GetImageSize (FLUX.2 edit) -> fixed numbers.
    for n in wf.values():
        ins = n.get("inputs", {})
        for key in ("width", "height"):
            v = ins.get(key)
            if _is_link(v) and (wf.get(v[0]) or {}).get("class_type") == "GetImageSize":
                ins[key] = width if key == "width" else height
    # Samplers whose latent is the encoded photo (Qwen / FireRed) -> empty latent.
    for nid, n in list(wf.items()):
        if n.get("class_type") not in SAMPLERS_WITH_LATENT:
            continue
        ins = n.get("inputs", {})
        lat = ins.get("latent_image")
        if _is_link(lat) and (wf.get(lat[0]) or {}).get("class_type") in LATENT_FROM_PHOTO:
            new_id = "user_canvas_" + str(nid).replace(":", "_")
            wf[new_id] = {
                "class_type": "EmptySD3LatentImage",
                "_meta": {"title": "User output size"},
                "inputs": {"width": width, "height": height, "batch_size": int(batch)},
            }
            ins["latent_image"] = [new_id, 0]
