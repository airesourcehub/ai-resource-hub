# AI Resource Hub — render service (desktop / RTX 3090)
# Exposed to the website via a Cloudflare Tunnel at render.airesourcehub.vip.
# Job kinds: blend | music_sync | motion_transfer (seat-gated, video) and
# image (any logged-in user, queued).  One GPU, one job at a time.

import os
import re
import json
import uuid
import time
import random
import shutil
import queue
import threading
import traceback
import subprocess
from pathlib import Path

import requests
from fastapi import FastAPI, UploadFile, File, Form, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
import uvicorn

try:
    import websocket  # websocket-client — live step/ETA feed (optional)
except Exception:
    websocket = None
try:
    import psutil      # CPU / RAM stats (optional)
except Exception:
    psutil = None

from image_support import patch_image_workflow, model_by_id, public_models, apply_quality
import studio_extras as SX

from dotenv import load_dotenv
load_dotenv()

# ------------------------------------------------------------------ config
SUPABASE_URL   = os.environ["SUPABASE_URL"].rstrip("/")
SUPABASE_ANON  = os.environ["SUPABASE_ANON_KEY"]
SERVICE_ROLE   = os.environ["SUPABASE_SERVICE_ROLE_KEY"]
COMFY_URL      = os.environ.get("COMFY_URL", "http://127.0.0.1:8188").rstrip("/")

WORKFLOWS = {
    ("landscape", "quality"): os.environ.get("WF_LANDSCAPE_QUALITY", "workflow_landscape_quality.json"),
    ("portrait",  "quality"): os.environ.get("WF_PORTRAIT_QUALITY",  "workflow_portrait_quality.json"),
    ("landscape", "fast"):    os.environ.get("WF_LANDSCAPE_FAST",     "workflow_landscape_fast.json"),
    ("portrait",  "fast"):    os.environ.get("WF_PORTRAIT_FAST",      "workflow_portrait_fast.json"),
}
WORKFLOW_PATH = os.environ.get("WORKFLOW_PATH", "workflow_api.json")

WORKFLOWS_MOTION = {
    "landscape": os.environ.get("MOTION_LANDSCAPE_FAST", "motion_landscape_fast.json"),
    "portrait":  os.environ.get("MOTION_PORTRAIT_FAST",  "motion_portrait_fast.json"),
}
ALLOWED_STEPS = (4, 8, 10, 12)
ALLOWED_FPS = (16, 24, 30)

IMAGE_WF_DIR   = Path(os.environ.get("IMAGE_WF_DIR", "image_workflows"))
LTX_WORKFLOW   = os.environ.get("LTX_WORKFLOW", "image_workflows/video_ltx2_3_ia2v.json")

# WAN text-to-video (identity videos). Export your WAN 2.2 t2v graph from
# ComfyUI (Save (API format)) and point WAN_T2V_WORKFLOW at it. The patcher
# below finds the sampler, sets the prompt, and stacks the chosen identity
# LoRAs onto the model — so no fixed node IDs are required.
WAN_T2V_WORKFLOW = os.environ.get("WAN_T2V_WORKFLOW", "image_workflows/wan_t2v.json")
WAN_FPS          = int(os.environ.get("WAN_FPS", "16"))
WAN_MAX_LORAS    = int(os.environ.get("WAN_MAX_LORAS", "4"))

# LoRA training via ai-toolkit (ostris). Point these at your install + base models.
AI_TOOLKIT_DIR   = os.environ.get("AI_TOOLKIT_DIR", r"C:\ai-toolkit")
AI_TOOLKIT_PY    = os.environ.get("AI_TOOLKIT_PY", os.path.join(AI_TOOLKIT_DIR, "venv", "Scripts", "python.exe"))
AI_TOOLKIT_RUN   = os.environ.get("AI_TOOLKIT_RUN", os.path.join(AI_TOOLKIT_DIR, "run.py"))
# Training base models. The site GENERATES on FLUX.2, so we TRAIN on FLUX.2
# too — a FLUX.1 LoRA won't apply on a FLUX.2 model. This needs (a) an
# ai-toolkit build that supports FLUX.2 and (b) the FLUX.2 dev weights on disk
# (the diffusers/safetensors model, NOT the GGUF you generate with).
#   TRAIN_FLUX_MODEL  → HF repo id or a local path to the FLUX.2 dev weights
#   TRAIN_FLUX_ARCH   → ai-toolkit arch key: "flux2" (v2) or "flux1" (legacy)
TRAIN_FLUX_MODEL = os.environ.get("TRAIN_FLUX_MODEL", "black-forest-labs/FLUX.2-dev")
TRAIN_FLUX_ARCH  = os.environ.get("TRAIN_FLUX_ARCH", "flux2")
TRAIN_WAN_MODEL  = os.environ.get("TRAIN_WAN_MODEL", "ai-toolkit/wan2.1-t2v-1.3b")

# Rough per-job durations (seconds) used only to estimate queue wait time.
AVG_DURATION = {
    "image": 45, "wan_video": 240, "motion_transfer": 300, "lipsync": 200,
    "blend": 200, "music_sync": 220, "training": 3000,
}
ALLOWED_BASES = ("flux", "wan")
ALLOWED_TRAIN_STEPS = (1000, 1500, 2500, 4000)
# Path to ComfyUI/models/loras so users can list + upload custom LoRAs.
COMFY_LORA_DIR = os.environ.get("COMFY_LORA_DIR", "").strip()

COMFY_CAP_SECS = int(os.environ.get("COMFY_CAP_SECS", "0"))
CLEAR_ON_SUBMIT = os.environ.get("CLEAR_ON_SUBMIT", "1") != "0"

WORK_DIR       = Path(os.environ.get("WORK_DIR", "./jobs")).resolve()
ALLOWED_ORIGINS = os.environ.get(
    "ALLOWED_ORIGINS", "https://airesourcehub.vip,https://www.airesourcehub.vip"
).split(",")
PORT           = int(os.environ.get("PORT", "8787"))
MAX_BYTES      = 250 * 1024 * 1024
MAX_LORA_BYTES = 600 * 1024 * 1024

WORK_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="AI Resource Hub render service")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in ALLOWED_ORIGINS if o.strip()],
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

JOBS = {}
JOB_QUEUE = queue.Queue()
LOCK = threading.Lock()
BUSY = False
QUEUE_IDS = []          # ordered ids waiting to run (front = next up)
CURRENT_JOB_ID = None   # the job the worker is processing right now
EMAIL_CACHE = {}        # user_id -> email (admin status page display)


def enqueue(job_id):
    """Put a job on the single-GPU work queue and remember its place in line."""
    with LOCK:
        QUEUE_IDS.append(job_id)
    JOB_QUEUE.put(job_id)


# ------------------------------------------------------------- supabase glue
def verify_user(authorization):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.split(" ", 1)[1]
    r = requests.get(f"{SUPABASE_URL}/auth/v1/user",
                     headers={"Authorization": f"Bearer {token}", "apikey": SUPABASE_ANON}, timeout=15)
    if r.status_code != 200:
        raise HTTPException(status_code=401, detail="Invalid session")
    return r.json()


def seat_holder_id():
    r = requests.get(f"{SUPABASE_URL}/rest/v1/render_seat",
                     params={"id": "eq.true", "select": "holder_id"},
                     headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE}, timeout=15)
    r.raise_for_status()
    rows = r.json()
    return rows[0]["holder_id"] if rows else None


def job_owner_id(job_id, table="render_jobs"):
    r = requests.get(f"{SUPABASE_URL}/rest/v1/{table}",
                     params={"id": f"eq.{job_id}", "select": "user_id"},
                     headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE}, timeout=15)
    if r.status_code != 200:
        return None
    rows = r.json()
    return rows[0]["user_id"] if rows else None


def delete_job_row(job_id, table="render_jobs"):
    try:
        requests.delete(f"{SUPABASE_URL}/rest/v1/{table}",
                        params={"id": f"eq.{job_id}"},
                        headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE}, timeout=15)
    except Exception:
        pass


def log_job_row(job_id, user_id, mode, prompt, status, render_type="ai_transition", **extra):
    body = {"id": job_id, "user_id": user_id, "mode": mode, "prompt": prompt,
            "status": status, "render_type": render_type, "updated_at": "now()"}
    body.update(extra)
    _upsert("render_jobs", body)


def log_image_row(job, status, **extra):
    body = {"id": job["id"], "user_id": job["user_id"], "model": job["model"],
            "mode": job.get("image_mode", "create"), "prompt": job.get("prompt"),
            "negative": job.get("negative"), "status": status,
            "width": job.get("width"), "height": job.get("height"),
            "batch": job.get("batch"), "lora": job.get("lora") or None, "updated_at": "now()"}
    body.update(extra)
    _upsert("image_jobs", body)


def _upsert(table, body):
    try:
        requests.post(f"{SUPABASE_URL}/rest/v1/{table}",
                      headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE,
                               "Content-Type": "application/json", "Prefer": "resolution=merge-duplicates"},
                      data=json.dumps(body), timeout=15)
    except Exception:
        pass


# ------------------------------------------------------------------ ffmpeg
def run(cmd):
    subprocess.run(cmd, check=True, capture_output=True)


def probe(video):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height,r_frame_rate", "-of", "json", str(video)])
    s = json.loads(out)["streams"][0]
    num, den = (s["r_frame_rate"].split("/") + ["1"])[:2]
    fps = float(num) / float(den) if float(den) else 30.0
    return int(s["width"]), int(s["height"]), round(fps, 3)


def probe_duration(path):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "json", str(path)])
    return float(json.loads(out)["format"]["duration"])


def has_audio(path):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "a",
        "-show_entries", "stream=index", "-of", "json", str(path)])
    return len(json.loads(out).get("streams", [])) > 0


def extract_last_frame(video, out_png):
    run(["ffmpeg", "-y", "-sseof", "-0.1", "-i", str(video), "-frames:v", "1", "-q:v", "1", str(out_png)])


def extract_first_frame(video, out_png):
    run(["ffmpeg", "-y", "-i", str(video), "-frames:v", "1", "-q:v", "1", str(out_png)])


def frame_at(video, t, out_png):
    run(["ffmpeg", "-y", "-ss", str(max(0.0, t - 0.001)), "-i", str(video),
         "-frames:v", "1", "-q:v", "1", str(out_png)])


def beats_of(video, workdir, tag):
    import numpy as np
    import librosa
    wav = workdir / (tag + ".wav")
    run(["ffmpeg", "-y", "-i", str(video), "-vn", "-ac", "1", "-ar", "22050", str(wav)])
    y, sr = librosa.load(str(wav), sr=None, mono=True)
    tempo, beats = librosa.beat.beat_track(y=y, sr=sr, units="time")
    return float(np.atleast_1d(tempo)[0]), [float(b) for b in beats]


def nearest_time(times, t):
    return t if not times else min(times, key=lambda x: abs(x - t))


def build_segment(video, v_ss, v_dur, w, h, fps, out, keep_audio):
    cmd = ["ffmpeg", "-y", "-ss", str(v_ss), "-t", str(v_dur), "-i", str(video)]
    vf = "[0:v]scale=%d:%d,fps=%s,setsar=1[v]" % (w, h, fps)
    if keep_audio:
        cmd += ["-filter_complex", vf, "-map", "[v]", "-map", "0:a?"]
    else:
        cmd += ["-f", "lavfi", "-t", str(v_dur), "-i", "anullsrc=r=48000:cl=stereo",
                "-filter_complex", vf, "-map", "[v]", "-map", "1:a"]
    cmd += ["-t", str(v_dur), "-ar", "48000", "-ac", "2",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(out)]
    run(cmd)


def build_transition_segment(trans, native_dur, target, w, h, fps, audio_src, a_ss, keep_audio, out):
    scale = target / native_dur if native_dur else 1.0
    vf = "[0:v]setpts=(PTS-STARTPTS)*%f,scale=%d:%d,fps=%s,setsar=1[v]" % (scale, w, h, fps)
    cmd = ["ffmpeg", "-y", "-i", str(trans)]
    if keep_audio:
        cmd += ["-ss", str(a_ss), "-t", str(target), "-i", str(audio_src),
                "-filter_complex", vf, "-map", "[v]", "-map", "1:a"]
    else:
        cmd += ["-f", "lavfi", "-t", str(target), "-i", "anullsrc=r=48000:cl=stereo",
                "-filter_complex", vf, "-map", "[v]", "-map", "1:a"]
    cmd += ["-t", str(target), "-ar", "48000", "-ac", "2",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(out)]
    run(cmd)


def finalize_mov(d, out_mp4):
    run(["ffmpeg", "-y", "-i", str(out_mp4), "-c", "copy", str(d / "result.mov")])


# ---------------------------------------------------------- system stats
def read_gpu():
    try:
        out = subprocess.check_output(
            ["nvidia-smi",
             "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw",
             "--format=csv,noheader,nounits"], timeout=10).decode("utf-8", "ignore")
    except Exception:
        return []
    gpus = []
    for line in out.strip().splitlines():
        p = [x.strip() for x in line.split(",")]
        def num(i):
            try: return float(p[i])
            except Exception: return None
        gpus.append({"name": p[0] if p else "GPU",
                     "util": num(1), "mem_used": num(2), "mem_total": num(3),
                     "temp": num(4), "power": num(5) if len(p) > 5 else None})
    return gpus


def read_cpu():
    if psutil is None:
        return None
    try:
        vm = psutil.virtual_memory()
        return {"percent": psutil.cpu_percent(interval=0.2),
                "cores": psutil.cpu_count(logical=True),
                "ram_used": round(vm.used / 1048576), "ram_total": round(vm.total / 1048576)}
    except Exception:
        return None


# ---------------------------------------------------------- ComfyUI bridge
def comfy_reset():
    for endpoint, payload in (("/interrupt", None), ("/queue", {"clear": True})):
        try:
            requests.post(f"{COMFY_URL}{endpoint}", json=payload, timeout=15)
        except Exception:
            pass


def comfy_upload_image(path):
    return comfy_upload_media(path, "image/png")


def comfy_upload_media(path, content_type):
    with open(path, "rb") as f:
        r = requests.post(f"{COMFY_URL}/upload/image",
                          files={"image": (Path(path).name, f, content_type)},
                          data={"overwrite": "true"}, timeout=300)
    r.raise_for_status()
    d = r.json()
    name = d["name"]
    if d.get("subfolder"):
        name = f"{d['subfolder']}/{name}"
    return name


def patch_workflow(wf, start_img, end_img, prompt, negative=None):
    for node_id, node in wf.items():
        title = (node.get("_meta") or {}).get("title", "")
        inputs = node.get("inputs", {})
        if title == "START_FRAME" and "image" in inputs:
            inputs["image"] = start_img
        elif title == "END_FRAME" and "image" in inputs:
            inputs["image"] = end_img
        elif title == "PROMPT" and "text" in inputs:
            inputs["text"] = prompt
        elif negative is not None and title in ("NEGATIVE", "NEGATIVE_PROMPT", "NEG") and "text" in inputs:
            inputs["text"] = negative
        if "noise_seed" in inputs and not isinstance(inputs["noise_seed"], list):
            inputs["noise_seed"] = random.randint(0, 2**63 - 1)
        if "seed" in inputs and not isinstance(inputs["seed"], list):
            inputs["seed"] = random.randint(0, 2**63 - 1)
    return wf


def to_4n1(frames):
    n = max(1, round((frames - 1) / 4.0))
    return int(4 * n + 1)


def patch_motion_workflow(wf, ref_image, drive_video, prompt, length_frames, steps=None, fps=None):
    for node_id, node in wf.items():
        title = (node.get("_meta") or {}).get("title", "")
        inputs = node.get("inputs", {})
        if title == "REF_IMAGE" and "image" in inputs:
            inputs["image"] = ref_image
        elif title == "DRIVE_VIDEO" and "file" in inputs:
            inputs["file"] = drive_video
        elif title == "PROMPT" and "text" in inputs:
            inputs["text"] = prompt
        elif title == "LENGTH" and "value" in inputs:
            inputs["value"] = length_frames
        if steps and "steps" in inputs and not isinstance(inputs["steps"], list):
            inputs["steps"] = steps
        if fps and "frame_rate" in inputs and not isinstance(inputs["frame_rate"], list):
            inputs["frame_rate"] = fps
        if "seed" in inputs and not isinstance(inputs["seed"], list):
            inputs["seed"] = random.randint(0, 2**63 - 1)
        if "noise_seed" in inputs and not isinstance(inputs["noise_seed"], list):
            inputs["noise_seed"] = random.randint(0, 2**63 - 1)
    return wf


def patch_lipsync_workflow(wf, image_name, audio_name, duration):
    for node_id, node in wf.items():
        ct = node.get("class_type")
        title = (node.get("_meta") or {}).get("title", "")
        inputs = node.get("inputs", {})
        if ct == "LoadImage" and "image" in inputs:
            inputs["image"] = image_name
        elif ct == "LoadAudio" and "audio" in inputs:
            inputs["audio"] = audio_name
            if "audioUI" in inputs:
                inputs["audioUI"] = ""
        elif ct == "PrimitiveFloat" and title == "Duration" and "value" in inputs:
            inputs["value"] = round(float(duration), 2)
        if "noise_seed" in inputs and not isinstance(inputs["noise_seed"], list):
            inputs["noise_seed"] = random.randint(0, 2**63 - 1)
        if "seed" in inputs and not isinstance(inputs["seed"], list):
            inputs["seed"] = random.randint(0, 2**63 - 1)
    return wf


def workflow_for(orientation, speed):
    path = WORKFLOWS.get((orientation, speed))
    if not path or not Path(path).exists():
        path = WORKFLOW_PATH
    return path


def workflow_for_motion(orientation):
    return WORKFLOWS_MOTION.get("portrait" if orientation == "portrait" else "landscape")


def _find_output_file(outputs):
    for node_id, out in outputs.items():
        for key in ("gifs", "videos", "images"):
            for item in out.get(key, []):
                fn = item.get("filename", "")
                if item.get("type", "output") == "output" and fn.lower().endswith((".mp4", ".webm", ".mov", ".gif", ".mkv")):
                    return item
    for node_id, out in outputs.items():
        for key in ("gifs", "videos", "images"):
            for item in out.get(key, []):
                fn = item.get("filename", "")
                if fn.lower().endswith((".mp4", ".webm", ".mov", ".gif", ".mkv")):
                    return item
    return None


def _collect_images(outputs):
    items = []
    for node_id, out in outputs.items():
        for item in out.get("images", []):
            if item.get("type", "output") == "output" and item.get("filename", "").lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
                items.append(item)
    return items


def _any_output(outputs):
    for out in outputs.values():
        if out.get("images") or out.get("gifs") or out.get("videos"):
            return True
    return False


def _ws_listen(client_id, prompt_id, job, stop):
    if websocket is None:
        return
    url = COMFY_URL.replace("https://", "wss://").replace("http://", "ws://") + "/ws?clientId=" + client_id
    try:
        ws = websocket.create_connection(url, timeout=6)
        ws.settimeout(2)
    except Exception:
        return
    started = {}
    try:
        while not stop.is_set():
            try:
                msg = ws.recv()
            except Exception:
                continue
            if not isinstance(msg, str):
                continue
            try:
                data = json.loads(msg)
            except Exception:
                continue
            typ = data.get("type")
            d = data.get("data") or {}
            pid = d.get("prompt_id")
            if pid and pid != prompt_id:
                continue
            if typ == "executing":
                if d.get("node") is not None:
                    job["eta_seconds"] = None
                    job["stage"] = "Preparing… (loading model / analyzing)"
                continue
            if typ != "progress":
                continue
            v = int(d.get("value") or 0)
            m = int(d.get("max") or 0)
            if m <= 0:
                continue
            node = str(d.get("node"))
            now = time.time()
            st = started.get(node)
            if st is None or v <= 1:
                started[node] = (now, v)
                st = started[node]
            t0, v0 = st
            done = v - v0
            spu = (now - t0) / done if done > 0 else 0
            job["step"] = v
            job["total_steps"] = m
            job["eta_seconds"] = int(spu * (m - v))
            job["stage"] = "Rendering — step %d of %d" % (v, m)
            frac = v / m
            job["progress"] = min(96, max(int(job.get("progress") or 20), int(20 + frac * 74)))
    finally:
        try:
            ws.close()
        except Exception:
            pass


def comfy_submit_and_wait(wf, job, cap_secs=None):
    """Returns the ComfyUI outputs dict for the finished prompt."""
    if cap_secs is None:
        cap_secs = COMFY_CAP_SECS
    if CLEAR_ON_SUBMIT:
        comfy_reset()
    client_id = str(uuid.uuid4())
    r = requests.post(f"{COMFY_URL}/prompt", json={"prompt": wf, "client_id": client_id}, timeout=60)
    if r.status_code != 200:
        raise RuntimeError("ComfyUI rejected the workflow: " + r.text[:400])
    prompt_id = r.json()["prompt_id"]
    job["prompt_id"] = prompt_id
    stop = threading.Event()
    threading.Thread(target=_ws_listen, args=(client_id, prompt_id, job, stop), daemon=True).start()
    t0 = time.time()
    try:
        while True:
            time.sleep(2)
            if job.get("cancel"):
                comfy_reset()
                raise RuntimeError("Cancelled by user")
            job["elapsed_seconds"] = int(time.time() - t0)
            h = requests.get(f"{COMFY_URL}/history/{prompt_id}", timeout=30)
            if h.status_code == 200 and prompt_id in h.json():
                entry = h.json()[prompt_id]
                stt = entry.get("status", {})
                if stt.get("status_str") == "error":
                    emsg = "ComfyUI failed to render (out of memory, or a model file is missing)."
                    for msg in stt.get("messages", []):
                        if isinstance(msg, list) and len(msg) >= 2 and msg[0] == "execution_error":
                            emsg = (msg[1] or {}).get("exception_message") or emsg
                            break
                    raise RuntimeError(emsg[:400])
                outs = entry.get("outputs", {})
                if _any_output(outs):
                    return outs
            if websocket is None:
                job["progress"] = min(92, 20 + job["elapsed_seconds"] // 8)
            if cap_secs and cap_secs > 0 and time.time() - t0 > cap_secs:
                raise RuntimeError("ComfyUI render timed out")
    finally:
        stop.set()


def comfy_run(workflow_path, start_img, end_img, prompt, job):
    wf = json.loads(Path(workflow_path).read_text(encoding="utf-8"))
    wf = patch_workflow(wf, start_img, end_img, prompt)
    return comfy_submit_and_wait(wf, job)


def comfy_fetch(item, dest):
    params = {"filename": item["filename"], "type": item.get("type", "output")}
    if item.get("subfolder"):
        params["subfolder"] = item["subfolder"]
    r = requests.get(f"{COMFY_URL}/view", params=params, timeout=180)
    r.raise_for_status()
    Path(dest).write_bytes(r.content)


# ----------------------------------------------------------------- workers
def process_image(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    m = model_by_id(job["model"])
    if not m:
        raise RuntimeError("Unknown model")

    job.update(status="processing", stage="Preparing…", progress=8)
    log_image_row(job, "processing", progress=8)

    input_name = None
    if m["type"] == "edit":
        if not (d / "input.png").exists():
            raise RuntimeError("This model edits a photo — please add an input image.")
        input_name = comfy_upload_media(d / "input.png", "image/png")

    wf = json.loads((IMAGE_WF_DIR / m["workflow"]).read_text(encoding="utf-8"))
    patch_image_workflow(
        wf, prompt=job["prompt"], negative=job.get("negative", ""),
        width=job.get("width", 1024), height=job.get("height", 1024), batch=job.get("batch", 1),
        lora_name=job.get("lora", "") or "", lora_strength=job.get("lora_strength", 1.0),
        input_image=input_name, model_type=m["type"], edit_size=job.get("edit_size", False))
    apply_quality(wf, job.get("quality", "medium"))

    job.update(stage="Generating…", progress=18)
    outs = comfy_submit_and_wait(wf, job)
    items = _collect_images(outs)
    if not items:
        raise RuntimeError("The model finished but returned no image.")

    urls = []
    for i, it in enumerate(items):
        fn = f"img_{i}.png"
        comfy_fetch(it, d / fn)
        urls.append(f"/files/{job_id}/{fn}")

    if job.get("upscale"):
        for i in range(len(urls)):
            job.update(stage=f"Upscaling to 4K ({i + 1}/{len(urls)})…",
                       progress=min(95, 70 + int(25 * i / max(1, len(urls)))))
            upscale_png(d / f"img_{i}.png", d / f"img_{i}.png", job)

    # record the real output size (edits that match the photo differ from the request)
    real = _png_size(d / "img_0.png")
    if real:
        job.update(width=real[0], height=real[1])

    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               urls=urls, result_url=urls[0])
    log_image_row(job, "done", progress=100, urls=urls)


def _png_size(path):
    try:
        with open(path, "rb") as f:
            head = f.read(24)
        if head[:8] == b"\x89PNG\r\n\x1a\n":
            return int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big")
    except Exception:
        pass
    return None


def log_training_row(job, status, **extra):
    body = {"id": job["id"], "user_id": job["user_id"], "name": job.get("name"),
            "base": job.get("base", "flux"), "trigger_word": job.get("trigger_word"),
            "status": status, "step": job.get("step"), "total_steps": job.get("total_steps"),
            "images": job.get("images"), "updated_at": "now()"}
    body.update(extra)
    _upsert("training_jobs", body)


def _safe_lora_name(name):
    s = re.sub(r"[^A-Za-z0-9_-]+", "_", (name or "lora").strip())
    return (s[:60] or "lora")


def make_train_config(name, base, trigger, dataset_dir, output_dir, steps):
    is_flux = (base == "flux")
    if is_flux:
        # FLUX.2 uses ai-toolkit's arch key; FLUX.1 used the legacy is_flux flag.
        if TRAIN_FLUX_ARCH == "flux2":
            model = {"name_or_path": TRAIN_FLUX_MODEL, "arch": "flux2", "quantize": True}
        else:
            model = {"name_or_path": TRAIN_FLUX_MODEL, "is_flux": True, "quantize": True}
    else:
        model = {"name_or_path": TRAIN_WAN_MODEL, "arch": "wan21", "quantize": True}
    proc = {
        "type": "sd_trainer",
        "training_folder": output_dir,
        "device": "cuda:0",
        "trigger_word": trigger or None,
        "network": {"type": "lora", "linear": 16, "linear_alpha": 16},
        "save": {"dtype": "float16", "save_every": max(250, int(steps)),
                 "max_step_saves_to_keep": 1, "push_to_hub": False},
        "datasets": [{"folder_path": dataset_dir, "caption_ext": "txt",
                      "caption_dropout_rate": 0.05, "cache_latents_to_disk": True,
                      "resolution": [512, 768, 1024]}],
        "train": {"batch_size": 1, "steps": int(steps), "gradient_accumulation_steps": 1,
                  "train_unet": True, "train_text_encoder": False,
                  "gradient_checkpointing": True, "noise_scheduler": "flowmatch",
                  "optimizer": "adamw8bit", "lr": 1e-4, "dtype": "bf16"},
        "model": model,
        "sample": {"sampler": "flowmatch", "sample_every": max(250, int(steps)),
                   "width": 1024, "height": 1024,
                   "prompts": [((trigger + " ") if trigger else "") + "portrait, high detail"],
                   "neg": "", "seed": 42, "walk_seed": True, "guidance_scale": 4, "sample_steps": 20},
    }
    return {"job": "extension", "config": {"name": name, "process": [proc]},
            "meta": {"name": name, "version": "1.0"}}


def process_training(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    ds = d / "dataset"
    job.update(status="processing", stage="Preparing dataset…", progress=5)
    log_training_row(job, "processing", progress=5)

    out_dir = d / "output"; out_dir.mkdir(parents=True, exist_ok=True)
    cfg = make_train_config(job["name"], job["base"], job.get("trigger_word", ""),
                            str(ds), str(out_dir), job["steps"])
    cfg_path = d / "config.json"
    cfg_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

    if not Path(AI_TOOLKIT_PY).exists():
        raise RuntimeError("ai-toolkit not found at " + AI_TOOLKIT_PY + " — set AI_TOOLKIT_DIR in .env")

    job.update(stage="Training… (this can take 30 min – a few hours)", progress=8,
               total_steps=job["steps"])
    proc = subprocess.Popen([AI_TOOLKIT_PY, AI_TOOLKIT_RUN, str(cfg_path)],
                            cwd=AI_TOOLKIT_DIR, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, bufsize=1)
    tail = []
    step_re = re.compile(r"(\d+)\s*/\s*(\d+)")
    t0 = time.time()
    try:
        for line in proc.stdout:
            if job.get("cancel"):
                proc.terminate()
                raise RuntimeError("Cancelled by user")
            line = line.rstrip()
            if line:
                print("[train]", line, flush=True)  # stream to the service console
                tail.append(line); del tail[:-80]
                job["log_tail"] = tail[-30:]  # surfaced on the status page
                # Give the phases before step-counting a visible stage + a little
                # progress movement, so the bar never looks frozen at the start.
                low = line.lower()
                if not job.get("step"):
                    if "caching" in low and "latent" in low:
                        job["stage"] = "Caching image latents…"
                        job["progress"] = max(job.get("progress", 8), 12)
                    elif "loading" in low and ("model" in low or "transformer" in low or "checkpoint" in low or "quantiz" in low):
                        job["stage"] = "Loading the base model…"
                        job["progress"] = max(job.get("progress", 8), 16)
                    elif "dataset" in low or "bucket" in low:
                        job["stage"] = "Preparing your images…"
                        job["progress"] = max(job.get("progress", 8), 10)
            m = step_re.search(line)
            if m:
                cur, tot = int(m.group(1)), int(m.group(2))
                if abs(tot - job["steps"]) <= 5 and cur <= tot:  # the main training bar
                    job["step"] = cur; job["total_steps"] = tot
                    job["stage"] = "Training — step %d / %d" % (cur, tot)
                    job["progress"] = min(96, int(18 + (cur / max(1, tot)) * 78))
                    job["eta_seconds"] = int((time.time() - t0) / max(1, cur) * (tot - cur)) if cur else None
            job["elapsed_seconds"] = int(time.time() - t0)
        code = proc.wait()
    finally:
        if proc.poll() is None:
            proc.terminate()

    if code != 0:
        raise RuntimeError("Training failed: " + " | ".join(tail[-25:]))

    saf = sorted(out_dir.rglob("*.safetensors"), key=lambda p: p.stat().st_mtime)
    if not saf:
        raise RuntimeError("Training finished but produced no .safetensors file.")
    final_name = _safe_lora_name(job["name"]) + ".safetensors"
    if COMFY_LORA_DIR and Path(COMFY_LORA_DIR).is_dir():
        shutil.copy(str(saf[-1]), str(Path(COMFY_LORA_DIR) / final_name))
        dest = final_name
    else:
        dest = str(saf[-1])
    job.update(status="done", stage="Done", progress=100, lora_file=dest)
    log_training_row(job, "done", progress=100, lora_file=dest)


def process_lipsync(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    face = d / "face.png"; audio = d / job["audio_file"]

    job.update(status="processing", stage="Preparing…", progress=8)
    log_job_row(job_id, job["user_id"], "lipsync", job.get("prompt", ""), "processing",
                render_type="lipsync", progress=8)

    try:
        dur = probe_duration(audio)
    except Exception:
        dur = 5.0
    dur = max(1.0, min(dur, 30.0))  # cap the clip length

    job.update(stage="Uploading to ComfyUI", progress=14)
    img_name = comfy_upload_media(face, "image/png")
    aud_name = comfy_upload_media(audio, job.get("audio_mime") or "audio/mpeg")

    job.update(stage="Preparing… (loading model)", progress=18)
    wf = json.loads(Path(LTX_WORKFLOW).read_text(encoding="utf-8"))
    wf = patch_lipsync_workflow(wf, img_name, aud_name, dur)
    outs = comfy_submit_and_wait(wf, job)

    job.update(stage="Assembling output", progress=96)
    out_mp4 = d / "result.mp4"
    comfy_fetch(_find_output_file(outs), out_mp4)
    tmp = d / "norm.mp4"
    run(["ffmpeg", "-y", "-i", str(out_mp4), "-c:v", "libx264", "-c:a", "aac",
         "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(tmp)])
    tmp.replace(out_mp4)
    finalize_mov(d, out_mp4)

    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
    log_job_row(job_id, job["user_id"], "lipsync", job.get("prompt", ""), "done",
                render_type="lipsync", progress=100,
                result_url=job["result_url"], result_mov_url=job["result_mov_url"])


def process_music(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    a = d / "clipA.mp4"; b = d / "clipB.mp4"
    no_music = bool(job.get("no_music"))
    job.update(status="processing",
               stage=("Cutting each clip at the middle" if no_music else "Analyzing the beat"),
               progress=8)
    log_job_row(job_id, job["user_id"], "music_sync", job["prompt"], "processing", progress=8)

    durA = probe_duration(a); durB = probe_duration(b)
    w, h, fps = probe(a)
    aud_a = has_audio(a); aud_b = has_audio(b)
    if not aud_a and not aud_b:
        no_music = True
    keep_audio = not no_music

    if no_music:
        cutA = durA / 2.0
        cutB = durB / 2.0
        beat_interval = None
    else:
        try: tempoA, beatsA = beats_of(a, d, "beatA")
        except Exception: tempoA, beatsA = 120.0, []
        try: tempoB, beatsB = beats_of(b, d, "beatB")
        except Exception: tempoB, beatsB = tempoA, []
        cutA = nearest_time(beatsA, durA / 2.0)
        cutB = nearest_time(beatsB, durB / 2.0)
        bpm = tempoA if tempoA and tempoA > 1 else 120.0
        beat_interval = 60.0 / bpm

    job.update(stage=("Extracting the middle frames" if no_music else "Extracting beat-aligned frames"), progress=16)
    start_png = d / "start.png"; end_png = d / "end.png"
    frame_at(a, cutA, start_png); frame_at(b, cutB, end_png)

    job.update(stage="Uploading frames to ComfyUI", progress=20)
    start_name = comfy_upload_image(start_png); end_name = comfy_upload_image(end_png)

    job.update(stage="Generating transition (WAN)", progress=22)
    wf = json.loads(Path(workflow_for(job["orientation"], job["speed"])).read_text(encoding="utf-8"))
    wf = patch_workflow(wf, start_name, end_name, job["prompt"])
    outs = comfy_submit_and_wait(wf, job)
    transition = d / "transition.mp4"; comfy_fetch(_find_output_file(outs), transition)

    native = probe_duration(transition)
    if no_music:
        target = native
        job.update(stage="Assembling output", progress=94)
    else:
        job.update(stage="Locking the transition to the beat", progress=94)
        n_beats = max(1, round(native / beat_interval))
        target = n_beats * beat_interval

    seg1 = d / "seg1.mp4"; segT = d / "segT.mp4"; seg3 = d / "seg3.mp4"
    build_segment(a, 0.0, cutA, w, h, fps, seg1, keep_audio and aud_a)
    build_transition_segment(transition, native, target, w, h, fps, a, cutA, keep_audio and aud_a, segT)
    build_segment(b, cutB, max(0.05, durB - cutB), w, h, fps, seg3, keep_audio and aud_b)

    job.update(stage="Assembling output", progress=97)
    out_mp4 = d / "result.mp4"
    if no_music:
        run(["ffmpeg", "-y", "-i", str(seg1), "-i", str(segT), "-i", str(seg3),
             "-filter_complex", "[0:v][1:v][2:v]concat=n=3:v=1:a=0[v]",
             "-map", "[v]", "-c:v", "libx264", "-pix_fmt", "yuv420p",
             "-movflags", "+faststart", str(out_mp4)])
    else:
        run(["ffmpeg", "-y", "-i", str(seg1), "-i", str(segT), "-i", str(seg3),
             "-filter_complex", "[0:v][0:a][1:v][1:a][2:v][2:a]concat=n=3:v=1:a=1[v][a]",
             "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-pix_fmt", "yuv420p",
             "-c:a", "aac", "-movflags", "+faststart", str(out_mp4)])
    finalize_mov(d, out_mp4)

    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
    log_job_row(job_id, job["user_id"], "music_sync", job["prompt"], "done", progress=100,
                result_url=job["result_url"], result_mov_url=job["result_mov_url"])

def upscale_png(src, dest, job, long_side=SX.UPSCALE_LONG_SIDE):
    """SeedVR2 4K upscale of one PNG (in place allowed)."""
    name = comfy_upload_media(src, "image/png")
    outs = comfy_submit_and_wait(SX.build_upscale(name, long_side), job)
    items = _collect_images(outs)
    if not items:
        raise RuntimeError("The upscaler finished but returned no image.")
    tmp = Path(str(dest) + ".tmp.png")
    comfy_fetch(items[0], tmp)
    try:   # drop the alpha channel: ~25% smaller, same picture
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(tmp), "-pix_fmt", "rgb24", str(dest)])
        tmp.unlink()
    except Exception:
        tmp.replace(dest)


def upscale_video(src, dest, job):
    """SeedVR2 video upscale to 1080p (long side 1920); exact 1920x1080 / 1080x1920 when the shape is close."""
    name = comfy_upload_media(src, "video/mp4")
    outs = comfy_submit_and_wait(SX.build_video_upscale(name), job)
    item = _find_output_file(outs)
    if not item:
        raise RuntimeError("The upscaler finished but returned no video.")
    raw = Path(str(dest) + ".raw.mp4")
    comfy_fetch(item, raw)
    w, h, _ = probe(raw)
    vf = "scale=trunc(iw/2)*2:trunc(ih/2)*2"
    if w and h:
        if w >= h and abs(w / h - 16 / 9) < 0.06: vf = "scale=1920:1080"
        elif h > w and abs(h / w - 16 / 9) < 0.06: vf = "scale=1080:1920"
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-vf", vf, "-c:v", "libx264", "-crf", "17",
         "-preset", "medium", "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(dest)])
    raw.unlink()


def process_video_upscale(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    extra = {"influencer_id": job.get("influencer_id")} if job.get("influencer_id") else {}
    job.update(status="processing", stage="Upscaling to 1080p… (loading SeedVR2)", progress=8)
    log_job_row(job_id, job["user_id"], "upscale_1080", job["prompt"], "processing",
                render_type="motion_transfer", progress=8, meta=_motion_meta(job), **extra)
    out_mp4 = d / "result.mp4"
    upscale_video(d / "source.mp4", out_mp4, job)
    finalize_mov(d, out_mp4)
    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
    log_job_row(job_id, job["user_id"], "upscale_1080", job["prompt"], "done",
                render_type="motion_transfer", progress=100, meta=_motion_meta(job),
                result_url=job["result_url"], result_mov_url=job["result_mov_url"], **extra)


def process_upscale(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    job.update(status="processing", stage="Upscaling to 4K…", progress=10)
    log_image_row(job, "processing", progress=10)
    upscale_png(d / "input.png", d / "img_0.png", job)
    real = _png_size(d / "img_0.png")
    if real:
        job.update(width=real[0], height=real[1])
    urls = [f"/files/{job_id}/img_0.png"]
    job.update(status="done", stage="Done", progress=100, eta_seconds=0, urls=urls, result_url=urls[0])
    log_image_row(job, "done", progress=100, urls=urls)


def restyle_reference(job, d, ref):
    """If the job asks for a style, repaint the reference first (Qwen Edit 2509).
    Returns the path to use as the character reference."""
    style = job.get("style") or ""
    has_img = (d / "style.png").exists()
    if not style and not has_img:
        return ref
    if has_img:
        prompt = (job.get("style_custom") or "").strip()[:600]
    else:
        prompt = SX.style_prompt(style, job.get("style_custom", ""))
        if not prompt:
            return ref
    job.update(stage="Applying style to your character…", progress=10)
    ref_name = comfy_upload_media(ref, "image/png")
    style_name = comfy_upload_media(d / "style.png", "image/png") if has_img else None
    outs = comfy_submit_and_wait(SX.build_restyle(ref_name, prompt, style_name), job)
    items = _collect_images(outs)
    if not items:
        raise RuntimeError("The style step returned no image.")
    out = d / "styled.png"
    comfy_fetch(items[0], out)
    job["styled_url"] = f"/files/{job['id']}/styled.png"
    return out


def _motion_meta(job):
    return {k: job.get(k) for k in ("res", "style", "length_secs", "target", "styled_url", "kind")
            if job.get(k) not in (None, "")}


def describe_image(image_name, job, limit=240):
    """Ask Qwen3-VL (in ComfyUI) to describe the character. Returns '' on any failure."""
    try:
        r = requests.post(f"{COMFY_URL}/prompt", json={"prompt": SX.build_caption(image_name),
                                                       "client_id": str(uuid.uuid4())}, timeout=60)
        if r.status_code != 200:
            return ""
        pid = r.json()["prompt_id"]
        t0 = time.time()
        while time.time() - t0 < limit:
            time.sleep(2)
            if job.get("cancel"):
                comfy_reset()
                raise RuntimeError("Cancelled by user")
            h = requests.get(f"{COMFY_URL}/history/{pid}", timeout=30)
            if h.status_code == 200 and pid in h.json():
                e = h.json()[pid]
                if (e.get("status") or {}).get("status_str") == "error":
                    return ""
                txt = ((e.get("outputs") or {}).get("c4") or {}).get("text") or []
                return (txt[0] if txt else "").strip()[:1200]
    except RuntimeError:
        raise
    except Exception:
        pass
    return ""


def process_swap(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    ref = d / "reference.png"; drive = d / "drive.mp4"
    extra = {"influencer_id": job.get("influencer_id")} if job.get("influencer_id") else {}

    job.update(status="processing", stage="Preparing inputs", progress=6)
    log_job_row(job_id, job["user_id"], "character_swap", job["prompt"], "processing",
                render_type="motion_transfer", progress=6, meta=_motion_meta(job), **extra)

    ref = restyle_reference(job, d, ref)

    secs = 10 if job.get("length_secs") == 10 else 5
    fps = SX.SWAP_FPS
    pre = d / "pre.mp4"
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(drive), "-t", str(secs + 1), "-r", str(fps),
         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(pre)])
    n = SX.swap_frames(int(probe_duration(pre) * fps), secs)
    drivef = d / "drivef.mp4"
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(pre), "-frames:v", str(n),
         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(drivef)])
    vw, vh, _ = probe(drivef)
    w, h = SX.size_for("720p" if job.get("res") == "1080p" else job.get("res", "480p"), vh > vw)

    job.update(stage="Uploading inputs to ComfyUI", progress=14)
    ref_name = comfy_upload_media(ref, "image/png")
    drive_name = comfy_upload_media(drivef, "video/mp4")

    job.update(stage="Studying your character…", progress=16)
    user_prompt = "" if job["prompt"] == SX.DEFAULT_SWAP_PROMPT else job["prompt"]
    caption = describe_image(ref_name, job)
    job["caption"] = caption
    prompt = SX.swap_prompt(caption, user_prompt)

    job.update(stage="Tracking and replacing… (loading models)", progress=18)
    wf = SX.build_swap(drive_name, ref_name, prompt=prompt, target=job.get("target"),
                       width=w, height=h, extend=n > SX.SEG_FRAMES)
    outs = comfy_submit_and_wait(wf, job)

    job.update(stage="Assembling output", progress=96)
    out_mp4 = d / "result.mp4"
    comfy_fetch(_find_output_file(outs), out_mp4)
    tmp = d / "norm.mp4"
    run(["ffmpeg", "-y", "-i", str(out_mp4), "-c:v", "libx264", "-pix_fmt", "yuv420p",
         "-c:a", "aac", "-movflags", "+faststart", str(tmp)])
    tmp.replace(out_mp4)
    if job.get("res") == "1080p":
        job.update(stage="Upscaling to 1080p…", progress=97)
        upscale_video(out_mp4, tmp, job)
        tmp.replace(out_mp4)
    finalize_mov(d, out_mp4)

    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
    log_job_row(job_id, job["user_id"], "character_swap", job["prompt"], "done",
                render_type="motion_transfer", progress=100, meta=_motion_meta(job),
                result_url=job["result_url"], result_mov_url=job["result_mov_url"], **extra)


def process_motion(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    ref = d / "reference.png"; drive = d / "drive.mp4"

    extra = {"influencer_id": job.get("influencer_id")} if job.get("influencer_id") else {}
    job.update(status="processing", stage="Preparing inputs", progress=8)
    log_job_row(job_id, job["user_id"], "motion_transfer", job["prompt"], "processing",
                render_type="motion_transfer", progress=8, meta=_motion_meta(job), **extra)
    ref = restyle_reference(job, d, ref)

    secs = 10 if job.get("length_secs") == 10 else 5
    fps = job.get("fps", 16)
    steps = job.get("steps", 4)
    drivef = d / "drivef.mp4"
    run(["ffmpeg", "-y", "-i", str(drive), "-t", str(secs), "-r", str(fps), "-an", str(drivef)])
    actual_frames = int(probe_duration(drivef) * fps)
    length_frames = to_4n1(max(5, min(fps * secs, actual_frames)))

    job.update(stage="Uploading inputs to ComfyUI", progress=14)
    ref_name = comfy_upload_media(ref, "image/png")
    drive_name = comfy_upload_media(drivef, "video/mp4")

    job.update(stage="Preparing… (loading model / analyzing motion)", progress=18)
    wf = json.loads(Path(workflow_for_motion(job["orientation"])).read_text(encoding="utf-8"))
    wf = patch_motion_workflow(wf, ref_name, drive_name, job["prompt"], length_frames, steps, fps)
    if job.get("res") in SX.MOTION_SIZES or job.get("res") == "1080p":
        base = "720p" if job.get("res") == "1080p" else job["res"]
        SX.set_motion_size(wf, *SX.size_for(base, job["orientation"] == "portrait", SX.MOTION_SIZES))
    outs = comfy_submit_and_wait(wf, job)

    job.update(stage="Assembling output", progress=96)
    out_mp4 = d / "result.mp4"
    comfy_fetch(_find_output_file(outs), out_mp4)
    tmp = d / "norm.mp4"
    run(["ffmpeg", "-y", "-i", str(out_mp4), "-c:v", "libx264", "-pix_fmt", "yuv420p",
         "-movflags", "+faststart", str(tmp)])
    tmp.replace(out_mp4)
    if job.get("res") == "1080p":
        job.update(stage="Upscaling to 1080p…", progress=97)
        upscale_video(out_mp4, tmp, job)
        tmp.replace(out_mp4)
    finalize_mov(d, out_mp4)

    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
    log_job_row(job_id, job["user_id"], "motion_transfer", job["prompt"], "done",
                render_type="motion_transfer", progress=100, meta=_motion_meta(job),
                result_url=job["result_url"], result_mov_url=job["result_mov_url"], **extra)


# ---------------------------------------------------------------- WAN t2v
# Generic graph patcher: works on any WAN 2.2 text-to-video API workflow
# without hard-coded node IDs. It locates the sampler, rewrites the positive
# / negative prompt text, sets the video dimensions + length on the latent
# node, and injects a chain of LoraLoaderModelOnly nodes for the identities.

def _wan_src_id(link):
    return str(link[0]) if isinstance(link, list) and link else None


def _wan_find_sampler(nodes):
    # Prefer a real sampler that carries both conditioning inputs.
    for nid, n in nodes.items():
        ins = n.get("inputs", {}) or {}
        ct = n.get("class_type", "")
        if ("Sampler" in ct or "sampler" in ct) and "positive" in ins and "negative" in ins:
            return nid, n
    for nid, n in nodes.items():
        ins = n.get("inputs", {}) or {}
        if "positive" in ins and "negative" in ins and "model" in ins:
            return nid, n
    return None, None


def _wan_set_text(nodes, start_id, text):
    seen, stack = set(), [start_id]
    while stack:
        nid = stack.pop()
        if nid is None or nid in seen or nid not in nodes:
            continue
        seen.add(nid)
        ins = nodes[nid].get("inputs", {}) or {}
        if isinstance(ins.get("text"), str):
            ins["text"] = text
            return True
        for v in ins.values():
            if isinstance(v, list) and v and not isinstance(v[0], (int, float, bool)):
                stack.append(str(v[0]))
            elif isinstance(v, list) and v and isinstance(v[0], int):
                stack.append(str(v[0]))
    return False


def _wan_new_id(nodes):
    n = 1
    while str(n) in nodes:
        n += 1
    return str(n)


def _wan_inject_loras(nodes, sampler, loras):
    ins = sampler.get("inputs", {}) or {}
    cur = ins.get("model")
    if not (isinstance(cur, list) and cur):
        return 0
    added = 0
    for fname, strength in loras:
        nid = _wan_new_id(nodes)
        nodes[nid] = {"class_type": "LoraLoaderModelOnly",
                      "inputs": {"model": cur, "lora_name": fname,
                                 "strength_model": float(strength)},
                      "_meta": {"title": "Identity LoRA"}}
        cur = [nid, 0]
        added += 1
    ins["model"] = cur
    return added


def _wan_set_latent(nodes, width, height, length):
    for n in nodes.values():
        ct = n.get("class_type", "")
        ins = n.get("inputs", {}) or {}
        looks_latent = ("Latent" in ct) or ("EmptyHunyuan" in ct) or ("width" in ins and "length" in ins)
        if not looks_latent:
            continue
        if "width" in ins and not isinstance(ins["width"], list):
            ins["width"] = int(width)
        if "height" in ins and not isinstance(ins["height"], list):
            ins["height"] = int(height)
        if "length" in ins and not isinstance(ins["length"], list):
            ins["length"] = int(length)


def patch_wan_workflow(wf, prompt, negative, width, height, length, loras):
    nodes = wf.get("prompt", wf) if isinstance(wf, dict) else wf
    sid, sampler = _wan_find_sampler(nodes)
    if not sampler:
        raise RuntimeError("Couldn't find a sampler in the WAN workflow — re-export it with 'Save (API format)'.")
    ins = sampler.get("inputs", {}) or {}
    if not _wan_set_text(nodes, _wan_src_id(ins.get("positive")), prompt):
        raise RuntimeError("Couldn't find the positive prompt node in the WAN workflow.")
    _wan_set_text(nodes, _wan_src_id(ins.get("negative")), negative or "")
    _wan_set_latent(nodes, width, height, length)
    if loras:
        _wan_inject_loras(nodes, sampler, loras)
    return wf


def process_wan(job_id):
    job = JOBS[job_id]
    d = WORK_DIR / job_id

    job.update(status="processing", stage="Preparing…", progress=8)
    log_job_row(job_id, job["user_id"], "wan_video", job.get("prompt", ""), "processing",
                render_type="wan_video", progress=8)

    secs = 5 if job.get("length_secs") == 5 else 3
    length_frames = to_4n1(max(5, WAN_FPS * secs))

    wf_path = Path(WAN_T2V_WORKFLOW)
    if not wf_path.is_absolute() and not wf_path.exists():
        wf_path = IMAGE_WF_DIR / Path(WAN_T2V_WORKFLOW).name
    if not wf_path.exists():
        raise RuntimeError("WAN workflow not found — set WAN_T2V_WORKFLOW to your exported graph.")

    job.update(stage="Preparing… (loading model)", progress=16)
    wf = json.loads(wf_path.read_text(encoding="utf-8"))
    wf = patch_wan_workflow(wf, job["prompt"], job.get("negative", ""),
                            job.get("width", 832), job.get("height", 480),
                            length_frames, job.get("loras", []))

    job.update(stage="Generating…", progress=20)
    outs = comfy_submit_and_wait(wf, job)

    job.update(stage="Assembling output", progress=96)
    out_mp4 = d / "result.mp4"
    comfy_fetch(_find_output_file(outs), out_mp4)
    tmp = d / "norm.mp4"
    run(["ffmpeg", "-y", "-i", str(out_mp4), "-c:v", "libx264", "-pix_fmt", "yuv420p",
         "-movflags", "+faststart", str(tmp)])
    tmp.replace(out_mp4)
    finalize_mov(d, out_mp4)

    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
    log_job_row(job_id, job["user_id"], "wan_video", job.get("prompt", ""), "done",
                render_type="wan_video", progress=100,
                result_url=job["result_url"], result_mov_url=job["result_mov_url"])


def _fail(job_id, job, e, *, image=False, render_type="ai_transition", mode=None):
    if job.get("cancel"):
        job.update(status="cancelled", stage="Cancelled", error="Cancelled by user")
        delete_job_row(job_id, "image_jobs" if image else "render_jobs")
        return
    if isinstance(e, subprocess.CalledProcessError):
        msg = "Processing failed: " + (e.stderr or b"").decode("utf-8", "ignore")[-400:]
    else:
        msg = str(e)[:400]
    job.update(status="error", error=msg)
    if image:
        log_image_row(job, "error", error=msg)
    else:
        log_job_row(job_id, job["user_id"], mode or job.get("mode"), job["prompt"], "error",
                    render_type=render_type, error=msg)


# --- Transform & Stay: wardrobe-morph prompt shaping ------------------------
# The morph is a first->last-frame WAN interpolation. To make "the outfit
# appears on the same guy" work (instead of a whole-frame melt), we LOCK the
# face / body / background / framing and tell the model that ONLY the clothing
# changes. We also strip the generic Identity-Lock clause if the user injected
# it, because it says "keep clothing consistent / do not morph" -- the exact
# opposite of a wardrobe transformation.
TRANSFORM_NEG = ("background change, scene change, different location, camera cut, "
                 "new background, different person, face swap, distorted face, "
                 "morphing face, warped features, melting, smearing, mush, blur, "
                 "double exposure, ghosting, deformed, extra limbs, low quality")

def _transform_morph_prompt(user_text):
    t = (user_text or "").strip()
    # Drop any generic identity-lock clause that fights a wardrobe change.
    i = t.find("Preserve the exact identity")
    if i != -1:
        t = t[:i].strip()
    outfit = t if t else "his outfit changes into new clothing"
    return ("Same man, exact same face, hair, skin and body, same pose, same "
            "background and camera framing, same lighting. Only his clothing "
            "changes: " + outfit + ". The new outfit and accessories materialize "
            "smoothly and cleanly onto him while his face, skin and the background "
            "stay completely unchanged and sharp. Photorealistic, one continuous "
            "shot, no scene change, no camera cut.")


def process_transform(job_id):
    """Transform & Stay: two clips of the same performance (A / B), flipped at the
    midpoint so the new scene STAYS, on time. 'crossfade' dissolves the real clips;
    'morph' inserts a short, prompt-driven WAN blend between the two middle frames.
    NOTE: the transformation comes from clip B / the two scenes -- not the text."""
    job = JOBS[job_id]
    d = WORK_DIR / job_id
    a = d / "clipA.mp4"; b = d / "clipB.mp4"
    style = job.get("middle_style", "crossfade")
    ov = float(job.get("overlap", 1.0))
    job.update(status="processing", stage="Preparing clips", progress=10)
    log_job_row(job_id, job["user_id"], "transform", job.get("prompt", ""), "processing",
                render_type="ai_transition", progress=10)

    durA = probe_duration(a); durB = probe_duration(b)
    w, h, fps = probe(a)
    aud_a = has_audio(a); aud_b = has_audio(b)
    keep_audio = aud_a and aud_b
    mA = durA / 2.0
    mB = durB / 2.0
    out_mp4 = d / "result.mp4"
    vf = f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:-1:-1,setsar=1,fps={fps}"

    if style == "morph":
        # Force the 20-step quality graph -- the fast 4-step LoRA runs at cfg 1 and
        # ignores the prompt, so a prompt-driven morph needs the quality workflow.
        start_png = d / "start.png"; end_png = d / "end.png"
        frame_at(a, mA, start_png); frame_at(b, mB, end_png)
        job.update(stage="Generating transition (WAN)", progress=25)
        start_name = comfy_upload_image(start_png); end_name = comfy_upload_image(end_png)
        wf = json.loads(Path(workflow_for(job["orientation"], "quality")).read_text(encoding="utf-8"))
        morph_pos = _transform_morph_prompt(job.get("prompt", ""))
        wf = patch_workflow(wf, start_name, end_name, morph_pos, negative=TRANSFORM_NEG)
        outs = comfy_submit_and_wait(wf, job)
        transition = d / "transition.mp4"; comfy_fetch(_find_output_file(outs), transition)
        native = probe_duration(transition)

        # Fit the transition to whatever room clip B has left, so we never leave a
        # broken zero-length tail. If B's back half is shorter than the generated
        # transition, we compress the transition to fit.
        roomB = max(0.0, durB - mB)
        tdur = native
        if roomB < native + 0.3:
            tdur = max(0.4, roomB - 0.3)
        b_start = min(mB + tdur, max(0.0, durB - 0.1))
        seg3_dur = durB - b_start

        seg1 = d / "seg1.mp4"; segT = d / "segT.mp4"; seg3 = d / "seg3.mp4"
        job.update(stage="Assembling output", progress=94)
        build_segment(a, 0.0, mA, w, h, fps, seg1, keep_audio and aud_a)
        build_transition_segment(transition, native, tdur, w, h, fps, a, mA, keep_audio and aud_a, segT)
        inputs = [seg1, segT]
        if seg3_dur >= 0.2:
            build_segment(b, b_start, seg3_dur, w, h, fps, seg3, keep_audio and aud_b)
            inputs.append(seg3)
        n = len(inputs)
        cmd = ["ffmpeg", "-y"]
        for f in inputs:
            cmd += ["-i", str(f)]
        if keep_audio:
            fc = "".join(f"[{i}:v][{i}:a]" for i in range(n)) + f"concat=n={n}:v=1:a=1[v][a]"
            cmd += ["-filter_complex", fc, "-map", "[v]", "-map", "[a]",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac",
                    "-movflags", "+faststart", str(out_mp4)]
        else:
            fc = "".join(f"[{i}:v]" for i in range(n)) + f"concat=n={n}:v=1:a=0[v]"
            cmd += ["-filter_complex", fc, "-map", "[v]",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-movflags", "+faststart", str(out_mp4)]
        run(cmd)
    else:
        # Crossfade. Pre-normalize BOTH slices to identical video (+re-encoded audio)
        # so xfade/acrossfade never trip over mismatched streams or a short clip.
        ov = max(0.3, min(ov, mA - 0.1, durA - mA - 0.05, durB - mB - 0.05, 4.0))
        if ov < 0.2:
            ov = 0.2
        job.update(stage="Cross-dissolving the two clips", progress=45)
        segA = d / "seg1.mp4"; segB = d / "seg3.mp4"
        if keep_audio:
            run(["ffmpeg", "-y", "-ss", "0", "-t", str(mA + ov), "-i", str(a),
                 "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p",
                 "-c:a", "aac", "-ar", "48000", "-ac", "2", str(segA)])
            run(["ffmpeg", "-y", "-ss", str(mB), "-i", str(b),
                 "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p",
                 "-c:a", "aac", "-ar", "48000", "-ac", "2", str(segB)])
            job.update(stage="Assembling output", progress=85)
            run(["ffmpeg", "-y", "-i", str(segA), "-i", str(segB),
                 "-filter_complex",
                 f"[0:v][1:v]xfade=transition=fade:duration={ov}:offset={mA}[v];"
                 f"[0:a][1:a]acrossfade=d={ov}[a]",
                 "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                 "-c:a", "aac", "-movflags", "+faststart", str(out_mp4)])
        else:
            run(["ffmpeg", "-y", "-ss", "0", "-t", str(mA + ov), "-i", str(a),
                 "-vf", vf, "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(segA)])
            run(["ffmpeg", "-y", "-ss", str(mB), "-i", str(b),
                 "-vf", vf, "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(segB)])
            job.update(stage="Assembling output", progress=85)
            run(["ffmpeg", "-y", "-i", str(segA), "-i", str(segB),
                 "-filter_complex", f"[0:v][1:v]xfade=transition=fade:duration={ov}:offset={mA}[v]",
                 "-map", "[v]", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                 "-movflags", "+faststart", str(out_mp4)])

    finalize_mov(d, out_mp4)
    job.update(status="done", stage="Done", progress=100, eta_seconds=0,
               result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
    log_job_row(job_id, job["user_id"], "transform", job.get("prompt", ""), "done",
                render_type="ai_transition", progress=100,
                result_url=job["result_url"], result_mov_url=job["result_mov_url"])


def process(job_id):
    job = JOBS[job_id]
    kind = job.get("kind")

    if kind == "image":
        try:
            process_image(job_id)
        except Exception as e:
            _fail(job_id, job, e, image=True)
        finally:
            try: (WORK_DIR / job_id / "input.png").unlink()
            except Exception: pass
        return

    if kind == "upscale":
        try:
            process_upscale(job_id)
        except Exception as e:
            _fail(job_id, job, e, image=True)
        finally:
            try: (WORK_DIR / job_id / "input.png").unlink()
            except Exception: pass
        return

    if kind == "video_upscale":
        try:
            process_video_upscale(job_id)
        except Exception as e:
            _fail(job_id, job, e, render_type="motion_transfer", mode="upscale_1080")
        finally:
            try: (WORK_DIR / job_id / "source.mp4").unlink()
            except Exception: pass
        return

    if kind == "character_swap":
        try:
            process_swap(job_id)
        except Exception as e:
            _fail(job_id, job, e, render_type="motion_transfer", mode="character_swap")
        finally:
            for f in ("reference.png", "drive.mp4", "pre.mp4", "drivef.mp4", "norm.mp4", "style.png"):
                try: (WORK_DIR / job_id / f).unlink()
                except Exception: pass
        return

    if kind == "motion_transfer":
        try:
            process_motion(job_id)
        except Exception as e:
            _fail(job_id, job, e, render_type="motion_transfer", mode="motion_transfer")
        finally:
            for f in ("reference.png", "drive.mp4", "drivef.mp4", "norm.mp4", "style.png"):
                try: (WORK_DIR / job_id / f).unlink()
                except Exception: pass
        return

    if kind == "lipsync":
        try:
            process_lipsync(job_id)
        except Exception as e:
            _fail(job_id, job, e, render_type="lipsync", mode="lipsync")
        finally:
            for f in ("face.png", job.get("audio_file", "audio.mp3"), "norm.mp4"):
                try: (WORK_DIR / job_id / f).unlink()
                except Exception: pass
        return

    if kind == "wan_video":
        try:
            process_wan(job_id)
        except Exception as e:
            _fail(job_id, job, e, render_type="wan_video", mode="wan_video")
        finally:
            for f in ("norm.mp4",):
                try: (WORK_DIR / job_id / f).unlink()
                except Exception: pass
        return

    if kind == "training":
        try:
            process_training(job_id)
        except Exception as e:
            if job.get("cancel"):
                job.update(status="cancelled", stage="Cancelled", error="Cancelled by user")
                delete_job_row(job_id, "training_jobs")
            else:
                msg = str(e)[:2000]
                job.update(status="error", error=msg)
                log_training_row(job, "error", error=msg)
        return

    if kind == "transform_stay":
        try:
            process_transform(job_id)
        except Exception as e:
            _fail(job_id, job, e, render_type="ai_transition", mode="transform")
        finally:
            for f in ("clipA.mp4", "clipB.mp4", "transition.mp4", "start.png", "end.png",
                      "seg1.mp4", "segT.mp4", "seg3.mp4"):
                try: (WORK_DIR / job_id / f).unlink()
                except Exception: pass
        return

    if kind == "music_sync":
        try:
            process_music(job_id)
        except Exception as e:
            _fail(job_id, job, e, mode="music_sync")
        finally:
            for f in ("clipA.mp4", "clipB.mp4", "transition.mp4", "start.png", "end.png",
                      "seg1.mp4", "segT.mp4", "seg3.mp4", "beatA.wav", "beatB.wav"):
                try: (WORK_DIR / job_id / f).unlink()
                except Exception: pass
        return

    d = WORK_DIR / job_id
    try:
        job.update(status="processing", stage="Extracting frames", progress=8)
        log_job_row(job_id, job["user_id"], job["mode"], job["prompt"], "processing", progress=8)
        a = d / "clipA.mp4"; b = d / "clipB.mp4"
        start_png = d / "start.png"; end_png = d / "end.png"
        extract_last_frame(a, start_png); extract_first_frame(b, end_png)

        job.update(stage="Uploading frames to ComfyUI", progress=15)
        start_name = comfy_upload_image(start_png); end_name = comfy_upload_image(end_png)

        job.update(stage="Generating transition (WAN)", progress=18)
        outs = comfy_run(workflow_for(job["orientation"], job["speed"]), start_name, end_name, job["prompt"], job)
        transition = d / "transition.mp4"; comfy_fetch(_find_output_file(outs), transition)

        job.update(stage="Assembling output", progress=95)
        out_mp4 = d / "result.mp4"
        if job["mode"] == "stitched":
            w, h, fps = probe(a)
            vf = (f"[0:v]scale={w}:{h},setsar=1,fps={fps}[a];"
                  f"[1:v]scale={w}:{h},setsar=1,fps={fps}[t];"
                  f"[2:v]scale={w}:{h},setsar=1,fps={fps}[b];"
                  f"[a][t][b]concat=n=3:v=1:a=0[outv]")
            run(["ffmpeg", "-y", "-i", str(a), "-i", str(transition), "-i", str(b),
                 "-filter_complex", vf, "-map", "[outv]", "-c:v", "libx264",
                 "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out_mp4)])
        else:
            run(["ffmpeg", "-y", "-i", str(transition), "-c:v", "libx264",
                 "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out_mp4)])
        finalize_mov(d, out_mp4)

        job.update(status="done", stage="Done", progress=100, eta_seconds=0,
                   result_url=f"/files/{job_id}/result.mp4", result_mov_url=f"/files/{job_id}/result.mov")
        log_job_row(job_id, job["user_id"], job["mode"], job["prompt"], "done", progress=100,
                    result_url=job["result_url"], result_mov_url=job["result_mov_url"])
    except Exception as e:
        _fail(job_id, job, e)
    finally:
        for f in ("clipA.mp4", "clipB.mp4", "transition.mp4", "start.png", "end.png"):
            try: (d / f).unlink()
            except Exception: pass


def worker_loop():
    global BUSY, CURRENT_JOB_ID
    while True:
        job_id = JOB_QUEUE.get()
        with LOCK:
            BUSY = True
            CURRENT_JOB_ID = job_id
            if job_id in QUEUE_IDS:
                QUEUE_IDS.remove(job_id)
        j = JOBS.get(job_id)
        if j is not None:
            j["started_at"] = time.time()
        try:
            process(job_id)
        except Exception:
            traceback.print_exc()  # never let one job kill the worker thread
        finally:
            with LOCK:
                BUSY = False
                CURRENT_JOB_ID = None
            JOB_QUEUE.task_done()


threading.Thread(target=worker_loop, daemon=True).start()


# ------------------------------------------------------------------ routes
async def _save_uploads(d, uploads, limit=MAX_BYTES):
    for upload, name in uploads:
        dest = d / name
        size = 0
        with open(dest, "wb") as out:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > limit:
                    raise HTTPException(status_code=413, detail="File too large")
                out.write(chunk)


def _new_job(**fields):
    base = {"id": None, "status": "queued", "progress": 2, "stage": "Queued", "eta_seconds": None,
            "elapsed_seconds": 0, "step": 0, "total_steps": 0, "cancel": False,
            "result_url": None, "result_mov_url": None, "urls": None, "error": None, "prompt_id": None,
            "started_at": None, "queued_at": time.time(), "log_tail": None}
    base.update(fields)
    return base


_GPU_OK = {}  # user_id -> (allowed, expires)


def _gpu_allowed(uid):
    """Christopher's GPU is for the admin plus members he has approved
    (gpu_access table). Everyone else connects their own PC."""
    now = time.time()
    hit = _GPU_OK.get(uid)
    if hit and hit[1] > now:
        return hit[0]
    try:
        r = requests.post(f"{SUPABASE_URL}/rest/v1/rpc/has_gpu_access",
                          headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE,
                                   "Content-Type": "application/json"},
                          data=json.dumps({"uid": uid}), timeout=10)
        ok = bool(r.json()) if r.status_code == 200 else None
    except Exception:
        ok = None
    if ok is None:          # Supabase hiccup: fall back to the admin check only
        return _is_admin(uid)
    _GPU_OK[uid] = (ok, now + 30)
    return ok


def _seat_gate(user):
    """Only the admin and approved members may queue jobs on this GPU; jobs
    run one at a time. The optional admin 'priority seat' still applies: if the
    admin has assigned the seat to someone, everyone else waits until it's cleared."""
    if not _gpu_allowed(user["id"]):
        raise HTTPException(status_code=403,
            detail="This GPU is private. Connect your own PC at airesourcehub.vip/gpu, or ask for access there.")
    holder = seat_holder_id()
    if holder and holder != user["id"]:
        raise HTTPException(status_code=423,
            detail="The GPU is reserved by the admin for another user right now. Please try again later.")


def _comfy_up():
    try:
        r = requests.get(f"{COMFY_URL}/system_stats", timeout=4)
        return r.status_code == 200
    except Exception:
        return False


def _is_admin(uid):
    try:
        r = requests.get(f"{SUPABASE_URL}/rest/v1/profiles",
                         params={"id": f"eq.{uid}", "select": "is_admin"},
                         headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE}, timeout=10)
        rows = r.json() if r.status_code == 200 else []
        return bool(rows and rows[0].get("is_admin"))
    except Exception:
        return False


def _email_for(uid):
    if not uid:
        return None
    if uid in EMAIL_CACHE:
        return EMAIL_CACHE[uid]
    try:
        r = requests.get(f"{SUPABASE_URL}/auth/v1/admin/users/{uid}",
                         headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE}, timeout=10)
        email = r.json().get("email") if r.status_code == 200 else None
    except Exception:
        email = None
    EMAIL_CACHE[uid] = email
    return email


def _owner_label(owner_id, viewer_id, viewer_is_admin):
    """Who a job belongs to, shown according to the viewer's privileges."""
    if owner_id == viewer_id:
        return "You"
    if viewer_is_admin:
        return _email_for(owner_id) or ("user " + str(owner_id)[:8])
    return "another member"


def _remaining_secs(job):
    """Best estimate of seconds left on a running job."""
    if not job:
        return 0
    eta = job.get("eta_seconds")
    if eta is not None and eta >= 0:
        return int(eta)
    avg = AVG_DURATION.get(job.get("kind") or job.get("mode"), 120)
    elapsed = int(time.time() - job["started_at"]) if job.get("started_at") else 0
    return max(0, avg - elapsed)


def _est_start_secs(position):
    """Seconds until a job at `position` in the queue (0 = next up) begins."""
    total = 0
    cur = JOBS.get(CURRENT_JOB_ID) if CURRENT_JOB_ID else None
    if cur:
        total += _remaining_secs(cur)
    for jid in QUEUE_IDS[:position]:
        j = JOBS.get(jid)
        total += AVG_DURATION.get((j or {}).get("kind"), 120)
    return total


def _job_summary(job_id, viewer_id, viewer_is_admin, position=None):
    j = JOBS.get(job_id)
    if not j:
        return None
    is_yours = j.get("user_id") == viewer_id
    return {
        "id": job_id if (is_yours or viewer_is_admin) else None,  # only for cancel rights
        "kind": j.get("kind") or j.get("mode"),
        "mode": j.get("mode"),
        "owner": _owner_label(j.get("user_id"), viewer_id, viewer_is_admin),
        "is_yours": is_yours,
        "stage": j.get("stage"),
        "progress": j.get("progress"),
        "eta_seconds": j.get("eta_seconds"),
        "elapsed_seconds": j.get("elapsed_seconds"),
        "step": j.get("step"), "total_steps": j.get("total_steps"),
        "position": position,
        "est_start_seconds": _est_start_secs(position) if position is not None else None,
    }


@app.on_event("startup")
def clear_orphans():
    for table in ("render_jobs", "image_jobs", "training_jobs"):
        try:
            requests.patch(
                f"{SUPABASE_URL}/rest/v1/{table}?status=in.(queued,processing)",
                headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE,
                         "Content-Type": "application/json", "Prefer": "return=minimal"},
                data=json.dumps({"status": "error", "error": "Service was restarted"}), timeout=15)
        except Exception:
            pass


@app.get("/health")
def health():
    return {"ok": True, "busy": BUSY}


@app.get("/gpu")
def gpu(authorization: str = Header(None)):
    verify_user(authorization)
    return {"gpus": read_gpu(), "cpu": read_cpu(), "busy": BUSY}


@app.get("/image-models")
def image_models():
    return {"models": public_models()}


@app.get("/loras")
def list_loras(authorization: str = Header(None)):
    verify_user(authorization)
    if not COMFY_LORA_DIR or not Path(COMFY_LORA_DIR).is_dir():
        return {"loras": [], "configured": False}
    names = sorted([p.name for p in Path(COMFY_LORA_DIR).glob("*.safetensors")])
    return {"loras": names, "configured": True}


@app.post("/loras")
async def upload_lora(file: UploadFile = File(...), authorization: str = Header(None)):
    user = verify_user(authorization)
    if not _gpu_allowed(user["id"]):
        raise HTTPException(status_code=403, detail="Only approved members can add LoRAs to this GPU.")
    if not COMFY_LORA_DIR or not Path(COMFY_LORA_DIR).is_dir():
        raise HTTPException(status_code=400, detail="LoRA folder isn't configured on the server.")
    name = Path(file.filename).name
    if not name.lower().endswith(".safetensors"):
        raise HTTPException(status_code=400, detail="LoRA must be a .safetensors file.")
    tmp = WORK_DIR / ("lora_" + uuid.uuid4().hex)
    tmp.mkdir(parents=True, exist_ok=True)
    try:
        await _save_uploads(tmp, ((file, name),), limit=MAX_LORA_BYTES)
        shutil.move(str(tmp / name), str(Path(COMFY_LORA_DIR) / name))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return {"ok": True, "name": name}


@app.delete("/my-loras/{job_id}")
def delete_my_lora(job_id: str, authorization: str = Header(None)):
    """Delete one of the caller's own trained LoRAs — removes the .safetensors
    from the shared LoRA folder and the training_jobs row."""
    user = verify_user(authorization)
    hdr = {"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE}
    r = requests.get(
        f"{SUPABASE_URL}/rest/v1/training_jobs?id=eq.{job_id}&select=user_id,lora_file",
        headers=hdr, timeout=15)
    rows = r.json() if r.status_code == 200 else []
    if not rows:
        raise HTTPException(status_code=404, detail="LoRA not found")
    if rows[0].get("user_id") != user["id"]:
        raise HTTPException(status_code=403, detail="That LoRA isn't yours.")
    lf = (rows[0].get("lora_file") or "").strip()
    if lf and "/" not in lf and "\\" not in lf and COMFY_LORA_DIR and Path(COMFY_LORA_DIR).is_dir():
        try:
            (Path(COMFY_LORA_DIR) / lf).unlink()
        except Exception:
            pass
    requests.delete(f"{SUPABASE_URL}/rest/v1/training_jobs?id=eq.{job_id}",
                    headers={**hdr, "Prefer": "return=minimal"}, timeout=15)
    return {"ok": True}


@app.post("/image-jobs")
async def create_image_job(
    prompt: str = Form(...), model: str = Form(...), mode: str = Form("create"),
    negative: str = Form(""), width: str = Form("1024"), height: str = Form("1024"),
    batch: str = Form("1"), lora: str = Form(""), lora_strength: str = Form("1.0"),
    image: UploadFile = File(None), authorization: str = Header(None),
    size: str = Form(""), quality: str = Form("medium"), res: str = Form(""),
):
    user = verify_user(authorization)
    _seat_gate(user)
    m = model_by_id(model)
    if not m:
        raise HTTPException(status_code=400, detail="Unknown model")
    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; d.mkdir(parents=True, exist_ok=True)
    if m["type"] == "edit":
        if image is None:
            shutil.rmtree(d, ignore_errors=True)
            raise HTTPException(status_code=400, detail="This model needs an input image.")
        await _save_uploads(d, ((image, "input.png"),))

    def clamp(v, lo, hi, dv):
        try: return max(lo, min(hi, int(v)))
        except Exception: return dv
    JOBS[job_id] = _new_job(
        id=job_id, kind="image", model=model, image_mode=("edit" if m["type"] == "edit" else "create"),
        prompt=prompt, negative=negative,
        width=clamp(width, 256, 2048, 1024), height=clamp(height, 256, 2048, 1024),
        batch=clamp(batch, 1, 4, 1), lora=(lora or "").strip(),
        lora_strength=(float(lora_strength) if lora_strength else 1.0), user_id=user["id"],
        # edits keep the photo's size unless the site asks for a set size (size=custom)
        edit_size=(m["type"] == "edit" and size == "custom"),
        quality=(quality if quality in ("low", "medium", "high") else "medium"),
        upscale=(res == "4k"))
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.post("/upscale-jobs")
async def create_upscale_job(
    image: UploadFile = File(None), source: str = Form(""), prompt: str = Form(""),
    authorization: str = Header(None),
):
    """Upscale one image to 4K: upload a file, or point at one of your results ('<job_id>/img_N.png')."""
    user = verify_user(authorization)
    _seat_gate(user)
    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; d.mkdir(parents=True, exist_ok=True)
    src_prompt = prompt
    if source:
        m = re.fullmatch(r"([0-9a-f-]{36})/(img_\d+\.png)", source.strip().split("/files/")[-1])
        if not m:
            shutil.rmtree(d, ignore_errors=True)
            raise HTTPException(status_code=400, detail="Bad source")
        sj = JOBS.get(m.group(1))
        owner = sj["user_id"] if sj else job_owner_id(m.group(1), "image_jobs")
        src = WORK_DIR / m.group(1) / m.group(2)
        if owner != user["id"] or not src.exists():
            shutil.rmtree(d, ignore_errors=True)
            raise HTTPException(status_code=404, detail="That image isn't on the GPU any more. Upload it instead.")
        shutil.copyfile(src, d / "input.png")
        if sj and not src_prompt:
            src_prompt = sj.get("prompt") or ""
    elif image is not None:
        await _save_uploads(d, ((image, "input.png"),))
    else:
        shutil.rmtree(d, ignore_errors=True)
        raise HTTPException(status_code=400, detail="Add an image to upscale.")
    JOBS[job_id] = _new_job(id=job_id, kind="upscale", model="seedvr2", image_mode="upscale",
                            prompt=(src_prompt or "Upscaled to 4K")[:2000], negative="",
                            width=None, height=None, batch=1, lora="", user_id=user["id"])
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.post("/video-upscale-jobs")
async def create_video_upscale_job(
    source: str = Form(""), video: UploadFile = File(None), authorization: str = Header(None),
):
    """Upscale one of your videos to 1080p: source = its job id (or /files/<id>/result.mp4), or upload a video."""
    user = verify_user(authorization)
    _seat_gate(user)
    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; d.mkdir(parents=True, exist_ok=True)
    meta = {"res": "1080p", "kind": "video_upscale"}
    prompt, inf = "Upscaled to 1080p", None
    if source:
        m = re.search(r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})", source)
        src = WORK_DIR / m.group(1) / "result.mp4" if m else None
        sj = JOBS.get(m.group(1)) if m else None
        owner = (sj["user_id"] if sj else job_owner_id(m.group(1))) if m else None
        if not src or owner != user["id"] or not src.exists():
            shutil.rmtree(d, ignore_errors=True)
            raise HTTPException(status_code=404, detail="That video isn't on the GPU any more.")
        shutil.copyfile(src, d / "source.mp4")
        if sj:
            prompt = sj.get("prompt") or prompt
            inf = sj.get("influencer_id")
            for k in ("length_secs", "style"):
                if sj.get(k): meta[k] = sj[k]
    elif video is not None:
        await _save_uploads(d, ((video, "source.mp4"),))
    else:
        shutil.rmtree(d, ignore_errors=True)
        raise HTTPException(status_code=400, detail="Pick a video to upscale.")
    JOBS[job_id] = _new_job(id=job_id, kind="video_upscale", mode="upscale_1080", prompt=prompt,
                            res="1080p", length_secs=meta.get("length_secs"), style=meta.get("style", ""),
                            influencer_id=inf, user_id=user["id"])
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.post("/training-jobs")
async def create_training_job(
    images: list[UploadFile] = File(...), name: str = Form(...),
    base: str = Form("flux"), trigger_word: str = Form(""), steps: str = Form("2500"),
    authorization: str = Header(None),
):
    user = verify_user(authorization)
    _seat_gate(user)
    if base not in ALLOWED_BASES:
        base = "flux"
    try:
        steps_v = int(steps)
    except Exception:
        steps_v = 2500
    if steps_v not in ALLOWED_TRAIN_STEPS:
        steps_v = 2500
    if len(images) < 4:
        raise HTTPException(status_code=400, detail="Please add at least 4 images (15–30 is ideal).")

    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; ds = d / "dataset"; ds.mkdir(parents=True, exist_ok=True)
    trig = (trigger_word or "").strip()
    try:
        for i, up in enumerate(images):
            ext = (Path(up.filename or "img.png").suffix or ".png").lower()
            if ext not in (".png", ".jpg", ".jpeg", ".webp"):
                ext = ".png"
            dest = ds / ("img_%03d%s" % (i, ext))
            size = 0
            with open(dest, "wb") as out:
                while True:
                    chunk = await up.read(1024 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise HTTPException(status_code=413, detail="An image is too large.")
                    out.write(chunk)
            (ds / ("img_%03d.txt" % i)).write_text(trig or name, encoding="utf-8")
    except Exception:
        shutil.rmtree(d, ignore_errors=True); raise

    JOBS[job_id] = _new_job(id=job_id, kind="training", mode="training", name=name.strip(),
                            base=base, trigger_word=trig, steps=steps_v, images=len(images),
                            user_id=user["id"])
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.post("/lipsync-jobs")
async def create_lipsync_job(
    image: UploadFile = File(...), audio: UploadFile = File(...),
    prompt: str = Form(""), authorization: str = Header(None),
):
    user = verify_user(authorization)
    _seat_gate(user)
    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; d.mkdir(parents=True, exist_ok=True)
    aext = (Path(audio.filename or "audio.mp3").suffix or ".mp3").lower()
    audio_file = "audio" + aext
    try:
        await _save_uploads(d, ((image, "face.png"), (audio, audio_file)))
    except Exception:
        shutil.rmtree(d, ignore_errors=True); raise
    JOBS[job_id] = _new_job(id=job_id, kind="lipsync", mode="lipsync", prompt=prompt,
                            audio_file=audio_file, audio_mime=(audio.content_type or "audio/mpeg"),
                            user_id=user["id"])
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.post("/wan-jobs")
async def create_wan_job(
    prompt: str = Form(...), negative: str = Form(""),
    width: str = Form("832"), height: str = Form("480"), length_secs: str = Form("3"),
    loras: str = Form(""), triggers: str = Form(""),
    authorization: str = Header(None),
):
    user = verify_user(authorization)
    _seat_gate(user)

    # Validate the chosen identity LoRAs (bare .safetensors filenames only).
    files, trigs = [], []
    for f in [x.strip() for x in (loras or "").split(",") if x.strip()]:
        if f.lower().endswith(".safetensors") and "/" not in f and "\\" not in f:
            files.append(f)
    for t in [x.strip() for x in (triggers or "").split(",")]:
        if t:
            trigs.append(t)
    if not files:
        raise HTTPException(status_code=400, detail="Pick at least one trained identity.")
    files = files[:WAN_MAX_LORAS]
    lora_pairs = [(f, 1.0) for f in files]

    # Make sure every trigger word is present in the prompt.
    p = prompt.strip()
    low = p.lower()
    missing = [t for t in trigs if t.lower() not in low]
    if missing:
        p = (", ".join(missing) + ", " + p) if p else ", ".join(missing)

    def clamp(v, lo, hi, dv):
        try: return max(lo, min(hi, int(v)))
        except Exception: return dv

    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; d.mkdir(parents=True, exist_ok=True)
    JOBS[job_id] = _new_job(
        id=job_id, kind="wan_video", mode="wan_video", prompt=p, negative=(negative or "").strip(),
        width=clamp(width, 256, 1280, 832), height=clamp(height, 256, 1280, 480),
        length_secs=(5 if length_secs == "5" else 3), loras=lora_pairs, user_id=user["id"])
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.post("/jobs")
async def create_job(
    videoA: UploadFile = File(...), videoB: UploadFile = File(...),
    prompt: str = Form(...), mode: str = Form("stitched"),
    orientation: str = Form("landscape"), speed: str = Form("quality"),
    kind: str = Form("blend"), no_music: str = Form(""),
    middle_style: str = Form("crossfade"), overlap: str = Form("1"),
    authorization: str = Header(None),
):
    user = verify_user(authorization)
    _seat_gate(user)
    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; d.mkdir(parents=True, exist_ok=True)
    try:
        await _save_uploads(d, ((videoA, "clipA.mp4"), (videoB, "clipB.mp4")))
    except Exception:
        shutil.rmtree(d, ignore_errors=True); raise

    if kind not in ("music_sync", "transform_stay"):
        kind = "blend"
    mode = kind if kind in ("music_sync", "transform_stay") else ("transition_only" if mode == "transition_only" else "stitched")
    orientation = "portrait" if orientation == "portrait" else "landscape"
    speed = "fast" if speed == "fast" else "quality"
    no_music_flag = str(no_music) in ("1", "true", "True", "yes")
    try: overlap_v = max(0.3, min(4.0, float(overlap)))
    except Exception: overlap_v = 1.0
    mstyle = "morph" if str(middle_style) == "morph" else "crossfade"
    JOBS[job_id] = _new_job(kind=kind, mode=mode, orientation=orientation, speed=speed,
                            prompt=prompt, no_music=no_music_flag,
                            middle_style=mstyle, overlap=overlap_v, user_id=user["id"])
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


def _own_influencer(uid, inf_id):
    """Return inf_id if it is a real influencer owned by uid, else None."""
    if not inf_id or not re.fullmatch(r"[0-9a-fA-F-]{36}", inf_id):
        return None
    try:
        r = requests.get(f"{SUPABASE_URL}/rest/v1/influencers",
                         params={"id": f"eq.{inf_id}", "user_id": f"eq.{uid}", "select": "id"},
                         headers={"Authorization": f"Bearer {SERVICE_ROLE}", "apikey": SERVICE_ROLE}, timeout=10)
        return inf_id if r.status_code == 200 and r.json() else None
    except Exception:
        return None


@app.get("/styles")
def list_styles():
    return {"styles": SX.public_styles()}


@app.post("/motion-jobs")
async def create_motion_job(
    image: UploadFile = File(...), video: UploadFile = File(...),
    prompt: str = Form(""), orientation: str = Form("landscape"),
    length: str = Form("5"), fps: str = Form("16"), steps: str = Form("4"),
    speed: str = Form(""), authorization: str = Header(None),
    mode: str = Form("motion"), res: str = Form(""), style: str = Form(""),
    style_custom: str = Form(""), style_image: UploadFile = File(None),
    target: str = Form("person"), influencer_id: str = Form(""),
):
    user = verify_user(authorization)
    _seat_gate(user)
    job_id = str(uuid.uuid4())
    d = WORK_DIR / job_id; d.mkdir(parents=True, exist_ok=True)
    try:
        ups = [(image, "reference.png"), (video, "drive.mp4")]
        if style_image is not None and getattr(style_image, "filename", ""):
            ups.append((style_image, "style.png"))
        await _save_uploads(d, ups)
    except Exception:
        shutil.rmtree(d, ignore_errors=True); raise
    style = style if (style == "custom" or style in SX.STYLE_PRESETS) else ""
    extras = dict(res=(res if res in ("480p", "720p", "1080p") else ""), style=style,
                  style_custom=(style_custom or "")[:600],
                  influencer_id=_own_influencer(user["id"], influencer_id))
    length_secs = 10 if str(length) == "10" else 5
    if mode == "swap":
        JOBS[job_id] = _new_job(id=job_id, kind="character_swap", mode="character_swap",
                                orientation=orientation, length_secs=length_secs,
                                prompt=(prompt.strip() or SX.DEFAULT_SWAP_PROMPT),
                                target=((target or "person").strip()[:120] or "person"),
                                user_id=user["id"], **{**extras, "res": extras["res"] or "480p"})
        enqueue(job_id)
        return {"job_id": job_id, "status": "queued"}

    orientation = "portrait" if orientation == "portrait" else "landscape"
    try: fps_v = int(fps)
    except Exception: fps_v = 16
    if fps_v not in ALLOWED_FPS: fps_v = 16
    try: steps_v = int(steps)
    except Exception: steps_v = 0
    if steps_v not in ALLOWED_STEPS:
        steps_v = 8 if speed == "quality" else 4
    JOBS[job_id] = _new_job(id=job_id, kind="motion_transfer", mode="motion_transfer", orientation=orientation,
                            length_secs=length_secs, fps=fps_v, steps=steps_v,
                            prompt=(prompt.strip() or SX.DEFAULT_MOTION_PROMPT), user_id=user["id"], **extras)
    enqueue(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.get("/jobs/{job_id}")
def get_job(job_id: str, authorization: str = Header(None)):
    user = verify_user(authorization)
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="No such job")
    if job["user_id"] != user["id"]:
        raise HTTPException(status_code=403, detail="Not your job")
    out = {k: job.get(k) for k in
           ("status", "progress", "stage", "mode", "orientation",
            "eta_seconds", "elapsed_seconds", "step", "total_steps",
            "result_url", "result_mov_url", "urls", "error", "log_tail")}
    # Waiting in line? Tell them their place + a rough time until they start.
    with LOCK:
        pos = QUEUE_IDS.index(job_id) if job_id in QUEUE_IDS else None
    if pos is not None:
        out["queue_position"] = pos + 1                       # 1-based for humans
        out["queue_ahead"] = pos
        out["est_start_seconds"] = _est_start_secs(pos)
        if job.get("status") == "queued":
            out["stage"] = ("Waiting in line — %d ahead of you" % pos) if pos else "You’re next up"
    return JSONResponse(out)


@app.get("/status")
def status(authorization: str = Header(None)):
    """Everything at a glance: service up, ComfyUI up, the running job (and who
    it belongs to), the queue, and live GPU/CPU stats."""
    user = verify_user(authorization)
    admin = _is_admin(user["id"])
    holder = seat_holder_id()
    current = _job_summary(CURRENT_JOB_ID, user["id"], admin) if CURRENT_JOB_ID else None
    with LOCK:
        waiting = list(QUEUE_IDS)
    queue = []
    for i, jid in enumerate(waiting):
        s = _job_summary(jid, user["id"], admin, position=i)
        if s:
            queue.append(s)
    seat_label = None
    if holder:
        seat_label = "You" if holder == user["id"] else (_email_for(holder) if admin else "another member")
    return {
        "service_up": True,
        "comfy_up": _comfy_up(),
        "busy": BUSY,
        "seat_holder": holder,
        "seat_label": seat_label,
        "you_are_admin": admin,
        "current": current,
        "queue": queue,
        "queue_len": len(queue),
        "gpus": read_gpu(),
        "cpu": read_cpu(),
    }


@app.post("/jobs/{job_id}/cancel")
def cancel_job(job_id: str, authorization: str = Header(None)):
    user = verify_user(authorization)
    job = JOBS.get(job_id)
    owner = job["user_id"] if job else None
    # Owner can cancel their own job; an admin can cancel anyone's (to free the GPU).
    if owner is not None and owner != user["id"] and not _is_admin(user["id"]):
        raise HTTPException(status_code=403, detail="Not your render")
    if job:
        job["cancel"] = True
    comfy_reset()
    return {"ok": True}


@app.delete("/jobs/{job_id}")
def delete_job(job_id: str, table: str = "render_jobs", authorization: str = Header(None)):
    user = verify_user(authorization)
    job = JOBS.get(job_id)
    owner = job["user_id"] if job else job_owner_id(job_id, table)
    if owner is not None and owner != user["id"]:
        raise HTTPException(status_code=403, detail="Not your render")
    if job:
        job["cancel"] = True
        comfy_reset()
    shutil.rmtree(WORK_DIR / job_id, ignore_errors=True)
    JOBS.pop(job_id, None)
    delete_job_row(job_id, table)
    return {"ok": True}


@app.get("/files/{job_id}/{name}")
def get_file(job_id: str, name: str):
    ok = name in ("result.mp4", "result.mov", "styled.png") or re.fullmatch(r"img_\d+\.png", name)
    if not ok:
        raise HTTPException(status_code=404, detail="Not found")
    path = WORK_DIR / job_id / name
    if not path.exists():
        raise HTTPException(status_code=404, detail="Not found")
    if name.endswith(".mp4"): media = "video/mp4"
    elif name.endswith(".mov"): media = "video/quicktime"
    else: media = "image/png"
    return FileResponse(str(path), media_type=media,
                        filename=f"render-{job_id[:8]}-{name}",
                        headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------- MCP connector
import sys as _sys
import mcp_tools
mcp_tools.register(app, _sys.modules[__name__])


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=PORT)
