# AI Resource Hub — GPU Connector "member mode".
# Runs the same render service the site's main GPU uses, adjusted for a member's own PC:
#   * only the PC's owner (the account that made the PC token) can use it
#   * no admin keys on this PC: database writes go through the gpu-connect relay,
#     which only ever touches the owner's own rows
#   * MCP requests are accepted only when they come through the site's MCP router
import hmac
import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlencode, urlsplit

import requests
from fastapi import HTTPException

from common import CONNECT_FN, SUPABASE_URL, VERSION, find_model_file, workflow_files

STATE = {"owner": None, "secret": None, "token": None, "public": None, "pc_name": None,
         "comfy_url": None, "models_dir": None, "info": {}}
REST = SUPABASE_URL + "/rest/v1/"
_orig_request = requests.Session.request


def _fake_response(status, content, url):
    r = requests.models.Response()
    r.status_code = status
    r._content = content if isinstance(content, bytes) else str(content).encode()
    r.headers["Content-Type"] = "application/json"
    r.url = url
    r.encoding = "utf-8"
    return r


def _relay(self, method, url, params=None, data=None, headers=None, json_body=None, **kw):
    parts = urlsplit(url)
    path = parts.path.split("/rest/v1/", 1)[1]
    table = path.strip("/")
    query = parts.query
    if params:
        extra = params if isinstance(params, str) else urlencode(params, doseq=True)
        query = (query + "&" + extra) if query else extra
    body = json_body
    if data is not None:
        try:
            body = json.loads(data if isinstance(data, (str, bytes)) else json.dumps(data))
        except Exception:
            body = None
    if table.startswith("rpc/") or table in ("render_seat", "profiles", "mcp_keys"):
        return _fake_response(200, b"[]", url)
    prefer = (headers or {}).get("Prefer")
    try:
        r = _orig_request(self, "POST", CONNECT_FN, json={
            "action": "rest", "token": STATE["token"], "method": method.upper(), "table": table,
            "query": query, "body": body, "prefer": prefer}, timeout=kw.get("timeout") or 20)
        return _fake_response(r.status_code, r.content, url)
    except Exception as e:
        return _fake_response(503, json.dumps({"error": str(e)}), url)


def _patched_request(self, method, url, *a, **kw):
    if isinstance(url, str) and url.startswith(REST):
        return _relay(self, method, url, params=kw.get("params"), data=kw.get("data"),
                      headers=kw.get("headers"), json_body=kw.get("json"), timeout=kw.get("timeout"))
    if isinstance(url, str) and url.startswith(SUPABASE_URL + "/auth/v1/admin/"):
        return _fake_response(403, b"{}", url)
    return _orig_request(self, method, url, *a, **kw)


def install_requests_hook():
    requests.Session.request = _patched_request


# ------------------------------------------------------------ model availability
_AVAIL = {"t": 0, "ids": None}


def available_model_ids(S):
    now = time.time()
    if _AVAIL["ids"] is not None and now - _AVAIL["t"] < 60:
        return _AVAIL["ids"]
    md = STATE["models_dir"]
    ids = []
    for m in S.IMAGE_MODELS if hasattr(S, "IMAGE_MODELS") else []:
        files = workflow_files(Path(S.IMAGE_WF_DIR) / m["workflow"])
        if md and files and all(find_model_file(md, f) for f in files):
            ids.append(m["id"])
    _AVAIL.update(t=now, ids=ids)
    return ids


def apply(S, mcp_tools):
    """Patch the imported server module for a member's PC."""
    import image_support
    S.IMAGE_MODELS = image_support.IMAGE_MODELS
    orig_verify = S.verify_user

    def verify_user(authorization):
        user = orig_verify(authorization)
        if not STATE["owner"]:
            raise HTTPException(status_code=503, detail="This PC is still connecting. Try again in a few seconds.")
        if user.get("id") != STATE["owner"]:
            raise HTTPException(status_code=403, detail="This PC belongs to another member.")
        return user

    S.verify_user = verify_user
    S._seat_gate = lambda user: None
    S.seat_holder_id = lambda: None
    S._is_admin = lambda uid: bool(uid) and uid == STATE["owner"]
    S._gpu_allowed = lambda uid: bool(uid) and uid == STATE["owner"]
    S._email_for = lambda uid: "You" if uid == STATE["owner"] else "another member"

    orig_public = image_support.public_models

    def public_models():
        ok = set(available_model_ids(S))
        return [m for m in orig_public() if m["id"] in ok]

    S.public_models = public_models

    orig_by_id = S.model_by_id

    def model_by_id(mid):
        m = orig_by_id(mid)
        if m and mid not in available_model_ids(S):
            raise HTTPException(status_code=400, detail=(
                m["name"] + " isn't installed on your PC yet. Run the GPU Connector Install file again and add its "
                "model pack (see airesourcehub.vip/gpu#packs)."))
        return m

    S.model_by_id = model_by_id

    if S.read_gpu() == [] and sys.platform == "darwin":
        gi = STATE["info"].get("gpu") or {}
        S.read_gpu = lambda: [{"name": gi.get("name") or "Apple GPU", "util": None, "mem_used": None,
                               "mem_total": (gi.get("vram_gb") or 0) * 1024 or None, "temp": None, "power": None}]

    # MCP: only via the site's router, which adds this PC's secret
    def auth_user(request, path_key=None):
        got = request.headers.get("x-airh-worker-secret", "")
        sec = STATE["secret"] or ""
        if sec and got and hmac.compare_digest(got.encode(), sec.encode()):
            return {"id": STATE["owner"], "owner": True}
        return None

    mcp_tools._auth_user = auth_user
    mcp_tools._lookup_key = lambda key: None
    mcp_tools.INSTRUCTIONS = (mcp_tools.INSTRUCTIONS.replace("the 3090", "this member's own PC")
                              .replace("RTX 3090", "member's own GPU"))

    @S.app.get("/connector")
    def connector_info():
        return {"ok": True, "version": VERSION, "pc": STATE["pc_name"], "online": bool(STATE["owner"]),
                "models": available_model_ids(S), "packs": STATE["info"].get("packs", []),
                "gpu": STATE["info"].get("gpu")}


def set_public_url(mcp_tools, url):
    STATE["public"] = url
    mcp_tools.PUBLIC_BASE = url
