@echo off
setlocal
cd /d "%~dp0"
title AI Resource Hub - GPU Connector setup
echo.
echo  AI Resource Hub - GPU Connector setup
echo  -------------------------------------
if not exist "tools\uv.exe" (
  echo  Getting the Python helper ^(uv^)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; New-Item -ItemType Directory -Force tools | Out-Null; Invoke-WebRequest 'https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip' -OutFile 'tools\uv.zip'; Expand-Archive 'tools\uv.zip' 'tools\uvtmp' -Force; Get-ChildItem 'tools\uvtmp' -Recurse -Filter 'uv*.exe' | Move-Item -Destination 'tools' -Force; Remove-Item 'tools\uv.zip','tools\uvtmp' -Recurse -Force"
)
if not exist "tools\uv.exe" (
  echo  Couldn't download uv. Check your internet connection and run this again.
  pause
  exit /b 1
)
set "AIRH_UV=%~dp0tools\uv.exe"
"tools\uv.exe" run --python 3.12 --with requests "connector\setup.py"
echo.
pause
